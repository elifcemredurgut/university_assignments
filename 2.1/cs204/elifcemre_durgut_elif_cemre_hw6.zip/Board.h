//Elif Cemre Durgut - 26493 - CS204 HW6
//Header file for Board class
//17.04.2020

#ifndef BOARD_H
#define BOARD_H

#include <iostream>

using namespace std;

class Board
{
	public:
		Board();                              //constructor
		void displayBoard();                  //displays the matrix
		char getOwner(int, int);              //returns the owner of the cell
		void setOwner(int, int, char);        //sets the owner of the cell
		bool isFull();                        //checks whether the board is full or not
		int countOwnedCells(char);            //returns the number of cells belong to the specific player

	private:
		char theBoard[2][6];                  // 2x6 matrix for the board of the game
};
#endif