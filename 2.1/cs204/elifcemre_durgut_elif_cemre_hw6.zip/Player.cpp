//Elif Cemre Durgut - 26493 - CS204 HW6
//Source file for Player class implementations
//17.04.2020

#include <iostream>
#include "Board.h"      //to be able to use member functions of this class (because board object is shared by both players)
#include "Player.h"

using namespace std;

void Player::move(int step) //player moves step times
{
	while(step > 0){  //until the number of steps ends
		if(direction == 1){ //clockwise direction
			if(row == 0 && col < 5)         //go straight
				col++;
			else if(row == 1 && col > 0)    //turn right
				col--;
			else if(row == 1 && col == 0)   //turn right
				row--;
			else if(row == 0 && col == 5)   //go straight
				row++;
		}
		else{  //counter-clockwise direction
			if(row == 0 && col == 0)        //turn left
				row++;
			else if(row == 1 && col == 5)   //turn left
				row--;
			else if(row == 0 && col > 0)    //go straight
				col--;
			else if(row == 1 && col < 5)    //go straight
				col++;
		}
		step--;
	}
}

void Player::claimOwnership()  //sets the ownership of the cell using Board.h functions
{
	if(board.getOwner(row, col) == '-') //if the cell is vacant
		board.setOwner(row, col, id);   //then set the ownership
}

bool Player::wins()  // returns true if the player has won the game
{
	bool isWinner = false;
	if(board.countOwnedCells(id) == 7)  //if a player gets 7 cells, then it wins the game
		isWinner = true;
	return isWinner;
}

int Player::getRow()  //returns current row to use in main since row is private data
{
	return row;
}

int Player::getCol()  //returns current column to use in main since it is private data
{
	return col;
}
