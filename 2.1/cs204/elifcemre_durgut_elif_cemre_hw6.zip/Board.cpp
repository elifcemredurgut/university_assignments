//Elif Cemre Durgut - 26493 - CS204 HW6
//Source file for Board class implementations
//17.04.2020

#include <iostream>
#include "Board.h"

using namespace std;

Board::Board() //default constructor
{
	for(int i = 0; i < 2; i++)
	{
		for(int j = 0; j < 6; j++)
		{
			theBoard[i][j] = '-';  //it initializes all the cells to '-' 
		}
	}
}

void Board::displayBoard()   //it displays the matrix
{
	for(int i = 0; i < 2; i++)
	{
		for(int j = 0; j < 6; j++)
		{
			cout << theBoard[i][j] << " ";
		}
		cout << endl;
	}
}

char Board::getOwner(int row, int col)   //it returns the owner of the given row and column
{
	char toBeReturned;     //character to be returned on the specific cell

	if(theBoard[row][col] == '-')
		toBeReturned = '-';
	else if(theBoard[row][col] == 'A')
		toBeReturned = 'A';
	else
		toBeReturned = 'B';

	return toBeReturned;
}

void Board::setOwner(int row, int col, char ch)  //it sets the ownership of the specified position on the board
{
	theBoard[row][col] = ch;   
}

bool Board::isFull() //it checks whether the board is full or not 
{
	bool fullness = true;
	for(int i = 0; i < 2; i++)
		for (int j = 0; j < 6; j++)
			if(theBoard[i][j] == '-')  //if there is a vacant cell
				fullness = false;
	return fullness;
}

int Board::countOwnedCells(char ch)  // it returns number of cells, that are owned by player specified by the parameter
{
	int num = 0; //the number of cells which belong to the player specified by the parameter
	for(int i = 0; i < 2; i++)
		for (int j = 0; j < 6; j++)
			if(theBoard[i][j] == ch)  //if the owner of the cell is player, then increase the num
				num++;
	return num;
}
