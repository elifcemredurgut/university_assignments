//Elif Cemre Durgut - 26493 - CS204 HW6
//Header file for Player class
//17.04.2020

#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "Board.h"

using namespace std;

class Player
{
	public:
		Player();                                                           //constructor
		Player::Player(Board & myboard, int id, int direction)
		: board(myboard), id(id), direction(direction), row(0), col(0)      //initializations
		{ }
		void move(int);                                                     //moves n steps (n=integer given by the program)
		void claimOwnership();                                              //sets the ownership of the cell using functions of Board class
		bool wins();                                                        // returns true if the player has won the game
		int getRow();                                                       //returns the current row since row is private data
		int getCol();                                                       //returns the current colun since column is private data

	private:
		char id;                                                            //identity of the player
		int row;                                                            //current row on the board
		int col;                                                            //current column on the board
		int direction;                                                      //clockwise OR counter-clockwise
		Board & board;            //object sharing method                   //board object which is shared by both of the players
};
#endif