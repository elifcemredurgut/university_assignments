/*  Elif Cemre Durgut - 26493 - First Homework - CS204
This homework finds an enclosed area in a 2D matrix and displays the path.
16/02/2020  */ 

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>

using namespace std;

void displayMatrix(const vector<vector<char>> & mat){  //This function displays the given matrix
	cout << "Input Matrix: " << endl;
	for(int i=0; i<mat.size(); i++){
		for(int j=0; j<mat[0].size(); j++){
			cout << mat[i][j] << "  " ;
		}
		cout << endl;
	}
}
bool charCheck(const vector<vector<char>> & mat, string fileName){ //This function checks the given matrix whether it contains any character other than x and o
	for(int i=0; i<mat.size(); i++){ 
		for(int j=0; j<mat[i].size(); j++){
			if((mat[i][j]=='x'|| mat[i][j]=='o')==false){ 
				cout << fileName << " includes invalid char(s)" << endl;
				return false;  //if the matrix contains characters other than x and o, it returns false
			}
		}
	}
	return true;
}

bool numCheck(const vector<vector<char>> & mat, string fileName){  //It checks the matrix whether it contains same amount of character in each row
	for(int k=0; k<mat.size()-1; k++){
		if(mat[k].size()!=mat[k+1].size()){
			cout << fileName << " is invalid matrix, does not contain same amount of char each row!" << endl;
			return false;
		}
	}
	return true;
}

void move(const vector<vector<char>> & mat, int & x, int & y, vector<vector<int>> & controlmat, int & controlValue){
	controlmat[x][y]=1; 
	//I have used short circuit feature of C++ in following if-else statements to not go out of matrix boundaries
	if(y!=mat[0].size()-1 && mat[x][y+1]=='x' && controlmat[x][y+1]!=1){ //RIGHT
		controlmat[x][y+1]=1;
		y++;
	}
	else if(x!=mat.size()-1 && mat[x+1][y]=='x' && controlmat[x+1][y]!=1){ //DOWN
		controlmat[x+1][y]=1;
		x++;
	}
	else if(y!=0 && mat[x][y-1]=='x' && controlmat[x][y-1]!=1){ //LEFT
		controlmat[x][y-1]=1;
		y--;
	}
	else if(x!=0 && mat[x-1][y]=='x' && controlmat[x-1][y]!=1){ //UP
		controlmat[x-1][y]=1;
		x--;
	}
	else
		controlValue=1; //This value was initially zero. If it turns to one, then this means it is dead-end-street and it cannot move any more.
}
int main(){
	string fileName;
	ifstream input;
	do{
		cout << "Please enter file name: ";
		cin >> fileName;
		input.open(fileName);
		if(input.fail()){
			cout << "Cannot find a file named " << fileName << endl;
		}
	}while(input.fail());

	string line;
	vector<vector<char>> mat;
	while(!input.eof())
	{
		getline(input, line);
		stringstream ss(line);
		
		char ch;
		vector<char> temp;
		while(ss >> ch)
		{
			temp.push_back(ch);		
		}
		mat.push_back(temp);
	}
	if(charCheck(mat, fileName)){ //If the matrix contains only x and o
		if(numCheck(mat, fileName)){ //If there are same amount of char in each row
			displayMatrix(mat);		
			int row,col;
			do{
				cout << "Please enter starting coordinates, first row X then column Y: ";
				cin >> row >> col;
				if(row == -1 && col==-1){
					cout << "Terminating..." << endl;
					return 0;
				}                       
				while(cin.fail() || row > mat.size()-1 || col > mat[0].size()-1) { //It should ask the user until s/he enters valid inputs
					cout << "Invalid Coordinates" << endl;
					cout << endl;
					cin.clear();
					cin.ignore(60,'\n'); //It ignores first 60 characters or until '\n' --> Reference: A Computer Science Tapestry, 1999, page:727 
					cout << "Please enter starting coordinates, first row X then column Y: ";
					cin >> row >> col;
				}
				//Vectors below were defined to store the visited cells
				vector<vector<int>> controlmat1(mat.size(), vector<int>(mat[0].size())); //for the first while loop
				vector<vector<int>> controlmat2(mat.size(), vector<int>(mat[0].size())); //for the second while loop
				int controlrow= row; //controlrow is constant and always equal to the row entered by the user
				int controlcol=col;  //controlcol is constant and always equal to the col entered by the user
				int controlValue = 0;  //to check whether the loop reached the farthest cell
				int num=0;
				if(mat[row][col]=='x'){
					while(controlValue == 0){
						move(mat, row, col, controlmat1, controlValue);
						num++;
					}
					if((row==controlrow && abs(controlcol-col)==1 && num>2) || (col==controlcol && abs(controlrow-row)==1 && num>2)){
						cout << "Found an enclosed area. The coordinates of the followed path:" << endl;
					}
					else 
						cout << "Cannot found an enclosed area starting with given coordinate. The coordinates of the followed path:" << endl;
					controlValue = 0;
					row=controlrow; //I have turned them back to their initial values(user input)
					col=controlcol;
					while(controlValue == 0){
						cout << row << "   " << col << endl;
						move(mat, row, col, controlmat2, controlValue);
					}
				}
				else
					cout << "This cell is not occupied!" << endl;
				cout << endl;
			}while(row != -1 && col!=-1); //if it is (-1,-1), then program should terminate.
		}
	}
	return 0;
}
