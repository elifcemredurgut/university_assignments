/*Elif Cemre Durgut - 26493 - Eight Homework - CS 204
This homework is about a multithreaded C++ program that simulates a queue of customers waiting in a store to pay their groceries.
15.05.2000*/

//Note: I copied the code for displaying the time from the ProducerConsumer.cpp and I used it multiple times so I did not write every time.

#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>
#include <iomanip>
#include <random> 
#include <time.h> 
#include "HW8DynIntQueue.h"

using namespace std;

int total_customer_count, remainder;  //remainder = total_customer_count - number of customers completed their checkout process
HW8DynIntQueue myQueue;
mutex myMutex, coutMutex;

//Begin: Code taken from the HW8 pdf
int random_range(const int & min, const int & max) {     //random number generator function
	static mt19937 generator(time(0));     
	uniform_int_distribution<int> distribution(min, max);     
	return distribution(generator); 
}
//End: Code taken from the HW8 pdf

void cashier1(int min, int max)
{
	int nrCustomer, size=0;  //nrCustomer means the number of dequeued customer from the queue
	this_thread::sleep_for (chrono::seconds(random_range(min, max)));

	while(remainder > 0){  //until all customers completed their process
		myMutex.lock();
		if(!myQueue.isEmpty()){
			myQueue.dequeue(nrCustomer);  //remove the customer from the queue
			size = myQueue.getCurrentSize();
			remainder--;
			myMutex.unlock();

			coutMutex.lock();
			time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			struct tm *ptm = new struct tm; 
			localtime_s(ptm, &tt); 
			cout << "Cashier 1 started transaction with customer " << nrCustomer << " (queue size is " << size << "): " << put_time(ptm,"%X") << endl;
			coutMutex.unlock();

			this_thread::sleep_for (chrono::seconds(random_range(min, max))); //simulation for checkout process

			coutMutex.lock();
			tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			localtime_s(ptm, &tt); 
			cout << "Cashier 1 finished transaction with customer " << nrCustomer << " " << put_time(ptm,"%X") << endl;
			coutMutex.unlock();
		}
		else{
			myMutex.unlock();
		}
	}
}

void cashier2(int min, int max, int threshold)
{
	int nrCustomer, size=0;  //nrCustomer means the number of dequeued customer from the queue
	this_thread::sleep_for (chrono::seconds(random_range(min, max)));

	while(remainder > 0){  ////until all customers completed their process
		myMutex.lock();
		if(myQueue.getCurrentSize() >= threshold){  //cashier 2 only works when the queue is greater than threshold value
			myQueue.dequeue(nrCustomer);
			size = myQueue.getCurrentSize();
			remainder--;
			myMutex.unlock();

			coutMutex.lock();
			time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			struct tm *ptm = new struct tm; 
			localtime_s(ptm, &tt); 
			cout << "Cashier 2 started transaction with customer " << nrCustomer << " (queue size is " << size << "): " << put_time(ptm,"%X") << endl;
			coutMutex.unlock();

			this_thread::sleep_for (chrono::seconds(random_range(min, max))); //simulation for checkout process

			coutMutex.lock();
			tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			localtime_s(ptm, &tt); 
			cout << "Cashier 2 finished transaction with customer " << nrCustomer << " " << put_time(ptm,"%X") << endl;
			coutMutex.unlock();
		}
		else{
			myMutex.unlock();
		}
	}
}

void customer(int min, int max)
{
	int size;
	for(int i = 1; i <= total_customer_count; i++){
		myMutex.lock();
		myQueue.enqueue(i);
		size = myQueue.getCurrentSize();  //add the new customer to the queue
		myMutex.unlock();

		coutMutex.lock();
		time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
		struct tm *ptm = new struct tm; 
		localtime_s(ptm, &tt); 
		cout << "New customer with ID " << i << " has arrived (queue size is " << size << "): " << put_time(ptm,"%X") << endl;
		coutMutex.unlock();

		this_thread::sleep_for (chrono::seconds(random_range(min, max)));  //simulation for randomly coming customers
	}
}
 
int main()
{
	int cashier2_threshold;
	int min_arrival, max_arrival, min_checkout_time, max_chechout_time;

	cout << "Please enter the total number of customers: ";
	cin >> total_customer_count;
	cout << "Please enter the number of customers waiting in the queue to open the second cashier: ";
	cin >> cashier2_threshold;
	cout << "Please enter the inter-arrival time range between two customers: "<< endl;
	cout << "Min: ";
	cin >> min_arrival;
	cout << "Max: ";
	cin >> max_arrival;
	cout << "Please enter the checkout time range of cashiers: " << endl;
	cout << "Min: ";
	cin >> min_checkout_time;
	cout << "Max: ";
	cin >> max_chechout_time;

	remainder = total_customer_count;

	time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
	struct tm *ptm = new struct tm; 
	localtime_s(ptm, &tt); 
	cout << "Simulation starts " << put_time(ptm,"%X") << endl;

	thread thr0(customer, min_arrival, max_arrival);
	thread thr1(cashier1, min_checkout_time, max_chechout_time);
	thread thr2(cashier2, min_checkout_time, max_chechout_time, cashier2_threshold);

	thr0.join();
	thr1.join();
	thr2.join();

	tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
	localtime_s(ptm, &tt); 
	cout << "End of the simulation ends " << put_time(ptm,"%X") << endl;

	return 0;
}