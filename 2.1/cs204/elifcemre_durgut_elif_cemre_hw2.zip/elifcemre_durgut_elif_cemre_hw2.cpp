/*  Elif Cemre Durgut - 26493 - Second Homework - CS204
This homework stores blacklisted credit cards and does some operations according to user's option.
27/02/2020  */ 

#include <iostream>
#include <string>
#include <sstream>          
#include <fstream>           
#include <vector>

using namespace std;

struct node{
	int month, year;
	vector<string> cards;
	node* next;
	//default constructor
	node::node ()
		:month(0), year(0), next(NULL)
	{}
};
// Begin: code taken from linkedList.cpp and modified

node * SearchList(node *head, int month,  int year, bool & existence) //It searches a node with given month and year
{   
	while (head != NULL)
	{
		if(head-> month == month && head-> year == year) {
			existence = true;
			return head;
		}
		head = head->next;
	}
	existence = false;
	return head;
}

void ClearList(node *head) 
{
	node *ptr;
	while(head!=NULL)
	{
		ptr=head;
		head=head->next;
		delete ptr;
	}
}
//End: code taken from linkedList.cpp

bool CardNumberCheck(string card){  //It checks whether the input card number is valid
	for(int i=0; i<card.size(); i++){
		if(card.at(i)<'0'|| card.at(i)>'9'){
			return false;
		}
	}
	return true;
}

node * SearchCard(node * head, string card, int & controlvalue){ //It searches a node with the given card number and returns this node
	node *  ptr = head; 
	while (ptr != NULL)
	{
		for(int i=0; i<ptr->cards.size(); i++) 
		{
			if(ptr->cards[i]==card){
				controlvalue=1;
				return ptr;
			}
		}
		ptr = ptr->next;
	}
	controlvalue = 0;
	return head; 
}
// Begin: Code taken from pointers 2.2 lecture slide
node * AddInOrder(node * head, int month, int year, string cardnumber)
{
   node *  ptr = head;   // loop variable
    if (head == NULL || year < head->year || (year==head->year && month<head->month))        
    {   
		node * temp = new node;  //node to be inserted 
		temp->month = month;
		temp->year = year;
		temp->cards.push_back(cardnumber);
		temp->next = head; //connect the rest
		return temp;
    }
    while (ptr->next != NULL && (ptr->next->year < year || (ptr->next->year==year && month > ptr->next->month)))
    {    
		ptr = ptr->next;
    }
	node * temp = new node;  //node to be inserted 
	temp->month = month;
	temp->year = year;
	temp->cards.push_back(cardnumber);
	temp->next = ptr->next; //connect the rest
	ptr->next = temp;

	return head;
}
// End: Code taken from pointers 2.2 lecture slide

node * ExpandVector(node * head, int month, int year, string cardnumber){ //It adds a new card number to the corresponding node's vector
	node * ptr = head;
	while (ptr->next != NULL)
    {    
		if(ptr->next->month == month && ptr->next->year == year)
			ptr->next->cards.push_back(cardnumber);
		ptr = ptr->next;
    }
	return head;
}

//Begin: Code taken from pointers 2.2 lecture slide
void DeleteOneNode (node * toBeDeleted, node * & head) 
{
	node * ptr;
	if (toBeDeleted == head)  //if the node to be deleted is the first node
	{   
		head = head->next;
		delete toBeDeleted;
	}
	else  //if the node to be deleted is in the middle or at the end
	{   
		ptr = head;
		while (ptr->next != toBeDeleted)
			ptr = ptr->next;
		ptr->next = toBeDeleted->next;
		delete toBeDeleted;
	}
}
//End: Code taken from pointers 2.2 lecture slide

void DisplayList (node * head)
{
	node * ptr = head;
    while (ptr != NULL) 
	{
		cout << "Expiration Date: " << ptr ->month << " " << ptr->year << endl;
		for(int i=0; i<ptr->cards.size(); i++) 
		{
			cout << i+1 << ") " << ptr->cards[i] << endl;
		}
		ptr = ptr->next;
		cout << "-------------------\n" << endl;
	}
}

int main(){
	string fileName;
	ifstream input;
	node *cardList = new node;  //my linklist
	int option;

	do{
		cout << "Please enter file name: ";
		cin >> fileName;
		input.open(fileName);
		if(input.fail()){
			cout << "Cannot find a file named " << fileName << endl;
		}
	}while(input.fail());
	
	string line;
	string cardnumber, inputcard;  //cardnumber is the number from txt file
	bool existence, existence2;
	int controlvalue1,controlvalue2;  //to check whether the SearchCard function finds a card 
	int inputmonth, filemonth;
	int inputyear, fileyear;
	while(getline(input, line)){
		istringstream strStream(line);
		strStream >> cardnumber >> filemonth >> fileyear ;
		SearchList(cardList, filemonth, fileyear, existence); 
		if(!existence){  
			cout << "New node is created with expiration date: "<< filemonth <<" "<< fileyear << endl;
			cout << "Credit card " << cardnumber << " added to node " << filemonth <<" "<< fileyear << endl;
			cout << "***************" << endl;
			AddInOrder(cardList, filemonth, fileyear, cardnumber);
		}
		
		else { //if it already exists
			cout << "Node with expiration date "<< filemonth <<" "<< fileyear << " already exists" << endl;
			cout << "Credit card " << cardnumber << " added to node " << filemonth <<" "<< fileyear << endl;
			cout << "***************" << endl;
			ExpandVector(cardList, filemonth, fileyear, cardnumber);
		}
	}

	do{
		cout << "\n1)Display List\n2)Card Search via Credit Number\n3)Delete Card with respect to Expiration Date\n4)Exit\n" << endl;
		cout << "Please choose option from the menu: ";
		cin >> option;
		cout << endl;
		if(option==4){
			cout << "Terminating!!!"<< endl;
			ClearList(cardList);
			return 0;
		}
		else if(option==1){
			if(cardList->next==NULL)
				cout << "List is empty!" << endl;
			else
				DisplayList(cardList->next);
		}
		else if(option==2){
			do{
				cout << "Please enter the credit card number: ";
				cin >> inputcard;
				if(inputcard.size()==16 && CardNumberCheck(inputcard)){
					SearchCard(cardList, inputcard, controlvalue1);
					if(controlvalue1==1){
						cout << "There exists a credit card given number " << inputcard <<" with expiration date: " << SearchCard(cardList, inputcard, controlvalue1)->month << " " << SearchCard(cardList, inputcard, controlvalue1)->year << endl;
					}
					else
						cout << "There is no credit card with given credit card number: " << inputcard << endl;
				}
				else
					cout <<"Invalid format!" << endl;
			}while(!(inputcard.size()==16 && CardNumberCheck(inputcard)));
		}
		else if(option==3){
			cout << "Please enter month and year: ";
			cin >> inputmonth >> inputyear;
			while(cin.fail() || inputmonth>12 || inputmonth<1) { 
					cout << "Invalid Date!" << endl;
					cin.clear();
					cin.ignore(60,'\n'); //It ignores first 60 characters or until '\n' --> Reference: A Computer Science Tapestry, 1999, page:727 
					cout << "Please enter month and year: ";
					cin >> inputmonth >> inputyear;
			}
			SearchList(cardList, inputmonth, inputyear, existence2);
			if(existence2){
				cout << "Node with expiration date " << inputmonth << " " << inputyear << " and the following credit cards have been deleted!" << endl;
				for(int i=0; i<SearchList(cardList, inputmonth, inputyear, existence2)->cards.size(); i++) 
				{
					cout << i+1 << ") " << SearchList(cardList, inputmonth, inputyear, existence2)->cards[i] << endl;
				} 

				DeleteOneNode(SearchList(cardList, inputmonth, inputyear, existence2), cardList);
			}
			else
				cout << "There is no node with expiration date " << inputmonth << " "<< inputyear <<", nothing deleted!" << endl;
		}
		else
			cout << "Invalid Option!" << endl; 

	}while(option!=4);
	return 0;
}