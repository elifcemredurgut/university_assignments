/*  Elif Cemre Durgut - 26493 - Fourth Homework - CS204
This homework fills a connected and closed area in a map with a given filling character
21/03/2020 
*/ 

#include <iostream>            
#include <string>
#include <sstream>          
#include <fstream> 
#include "CoorList.h"

using namespace std;

void getInput(string thing, int & input){
	string error;
	cout << "Enter the number of " << thing << "s: " ;
	cin >> input;
	while(cin.fail() || input < 3) {  //If input is smaller than 3 or a non-intenger value
		if(cin.fail()){
			cin.clear();
			cin >> error;
			cout << error << " is not valid!" << endl;
		}
		else
			cout << input << " is not valid!" << endl;
		cin.clear();
		cin.ignore(60,'\n'); //It ignores first 60 characters or until '\n' --> Reference: A Computer Science Tapestry, 1999, page:727 
		cout << "Enter the number of " << thing << "s: ";
		cin >> input;
	}
}

int main(){
	int row_num, col_num;  //number of rows/columns entered by the user
	int row, col;
	char ch;
	CoorList CoorList;  //Coordinate List
	string fileName;
	ifstream input;

	getInput("row", row_num);
	getInput("column", col_num);
	
	do{
		cout << "Please enter file name: ";
		cin >> fileName;
		input.open(fileName);
		if(input.fail()){
			cout << "Cannot open a file named " << fileName << endl;
		}
	}while(input.fail());

	// Begin: code taken from matrix.cpp and updated (Lab 5)

	//Two dimensional dynamic array creation
	char** dmatrix = new char*[row_num];
	for(int i =0; i<row_num; i++)
	{
		dmatrix[i] = new char[col_num];
	}
	// End: code taken from matrix.cpp and updated (Lab 5)
	
	string line;
	int m = 0;
	//Filling the characters of matrix according to the txt file
	while(getline(input, line)){  
		for(int k=0; k<col_num; k++){
			dmatrix[m][k]=line[k];
		}
		m++;
	}

	cout << "Enter the starting point: ";
	cin >> row >> col;
	while(cin.fail() || row >= row_num || col >= col_num || row < 0 || col < 0){
		cout << "Invalid coordinate!" << endl;
		cin.clear();
		cin.ignore(60, '\n');
		cout << "Enter the starting point: ";
		cin >> row >> col;
	}
	
	if(dmatrix[row][col] == 'X'){  //if the point is non-empty
		cout << "Starting point is already occupied.\nTerminating... " << endl;
	}
	else{
		do{
			cout << "Enter the filling char: ";
			cin >> ch;
			if (ch == 'x' || ch == 'X')
				cout << "Filling char is not valid!" << endl;
		}while(ch == 'x' || ch == 'X');

		dmatrix[row][col] = ch;
		CoorList.push(row, col);

		do{
			if (dmatrix[row][col-1] == ' '){  //GO LEFT
				col--;
				CoorList.push(row, col);
				dmatrix[row][col] = ch;
			}
			else if (dmatrix[row-1][col] == ' '){  //GO UP
				row--;
				CoorList.push(row, col);
				dmatrix[row][col] = ch;
			}
			else if (dmatrix[row][col+1] == ' '){  //GO RIGHT
				col++;
				CoorList.push(row, col);
				dmatrix[row][col] = ch;
			}
			else if (dmatrix[row+1][col] == ' '){  //GO DOWN
				row++;
				CoorList.push(row, col);
				dmatrix[row][col] = ch;
			}
			else
				CoorList.pop(row, col);
		}while(!CoorList.isEmpty());

		//displaying matrix
		for(int i=0; i<row_num; i++)
		{
			for(int j=0; j<col_num; j++)
			{
				cout << dmatrix[i][j] << " ";
			}
			cout << endl;
		}
	
		//deleting matrix

		// Begin: code taken from 2.2 pointers-linkedlists slide, page 28 and modified
		for (int i = 0; i< row_num; i++) // Returning memory to free heap for reuse 
			delete[] dmatrix[i];
		delete[] dmatrix; 
		// End: code taken from 2.2 pointers-linkedlists slide, page 28 and modified
	}
	
	return 0;
}
