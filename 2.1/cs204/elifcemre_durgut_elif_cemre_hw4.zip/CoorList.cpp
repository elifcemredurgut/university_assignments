//Elif Cemre Durgut - 26493 - Fourth Homework - CS204
//Source File for member functions

#include "CoorList.h"
#include <iostream>

using namespace std;

CoorList::CoorList()  //constructor
{
	top = NULL;
}

CoorList::~CoorList()  //destructor
{
	CoordinateNode * ptr = top;
    while (ptr != NULL) 
	{
		CoordinateNode * temp = ptr->next;
		delete ptr;
		ptr = temp;
	}
}

// Begin: code taken from DynamicStringStack.cpp and updated

void CoorList::push(int x, int y)
{
	CoordinateNode * newNode;
	newNode = new CoordinateNode;
	newNode->x = x;
	newNode->y = y;

	if(isEmpty())  //if the stack is empty, it forms the first node
	{
		top = newNode;
		newNode->next = NULL;
	}
	else  // It adds to the beginning of the stack
	{
		newNode->next = top;
		top = newNode;
	}
}

void CoorList::pop(int & x, int & y)
{
	CoordinateNode *temp;

	temp = top->next;
	delete top;    // It removes the first element of the stack
	top = temp;
	if(top != NULL){
		x = top->x;  //It returns x and y values of the new top with pass by reference
		y = top->y;
	}
}

bool CoorList::isEmpty()
{
	if(top == NULL)  //if the list is empty
		return true;
	else
		return false;
}
// End: code taken from DynamicStringStack.cpp and updated