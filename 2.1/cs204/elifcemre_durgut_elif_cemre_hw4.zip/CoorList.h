//Elif Cemre Durgut - 26493 - Fourth Homework - CS204
//Header file

#ifndef _COORLIST_H_
#define _COORLIST_H_

using namespace std;

struct CoordinateNode
{
	int x, y;
	CoordinateNode *next;

	CoordinateNode::CoordinateNode()
	{}
	CoordinateNode::CoordinateNode(int xcoor, int ycoor, CoordinateNode * linkNext)
		: x(xcoor), y(ycoor), next(linkNext)
	{}
};

class CoorList
{
public:
	CoorList();  // constructor
	~CoorList(); //destructor
	void push(int x, int y);  //It adds the given coordinates to the beginning of the list
	void pop(int & x, int & y);  //It removes the first coordinate
	bool isEmpty(void);   //It returns true if the list is empty

private:
	CoordinateNode * top;  // first element of the list

};
#endif