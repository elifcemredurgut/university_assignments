//Elif Cemre Durgut - 26493 - Fifth Homework - CS204
//Source File for class implementations + free functions
// 13/04/2020

#include "IntegerSet.h"
#include <iostream>

using namespace std;

// Begin: code taken from MathVector.cpp and updated 
// constructor
IntegerSet::IntegerSet()
{
	size = 0;
	set = NULL;
}

// constructor with vector size
IntegerSet::IntegerSet(int psize)
{
	if(psize <= 0)
		set = NULL;
	else{
		set = new int[psize];
		size = psize;
		for(int i = 0; i < psize; i++){
			set[i] = i;
		}
	}
}

// destructor
IntegerSet::~IntegerSet()
{
	size = 0;
	delete[] set;
}

// copy constructor - deep copy
IntegerSet::IntegerSet(const IntegerSet & copy)
{
	size = copy.size;
	set = new int[size]; // deep copy

	for(int i = 0; i < size; i++)
	{
		set[i] = copy.set[i];
	}
}

// 1-) = operator // equalize the lhs to rhs
const IntegerSet & IntegerSet :: operator = (const IntegerSet & rhs){
	if (this != &rhs) // if they are not already equal                          
	{
		// first delete left hand side
		size = 0;
		delete[] set;

		// create new vector for left hand side
		size = rhs.size;
		set = new int[size];

		for(int i = 0; i < size; i++)
		{
			set[i] = rhs.set[i]; // assign content
		}
	}

	return *this;
}
// End: code taken from MathVector.cpp and updated 

//  2-) + operator // union of two sets
IntegerSet IntegerSet :: operator + (const IntegerSet & rhs) const{
	IntegerSet result(rhs);   //copy the rhs
	IntegerSet temp(*this);
	result += temp;           //add lhs to rhs        
	return result;
}

// 3-) + operator // adding element
IntegerSet IntegerSet :: operator + (int x){
	if(!isElement(x)){
		IntegerSet temp(size+1);
		for(int j = 0; j <= size-1; j++){
			temp.set[j] = set[j];
		}
		temp.set[size] = x;
		return temp;
	}
	else{
		IntegerSet temp(*this);
		return temp;
	}
}

//  4-) * operator  // intersection of two sets
IntegerSet IntegerSet :: operator * (const IntegerSet & rhs) const{  
	IntegerSet result;
	for(int i = 0; i < size; i++){
		if(rhs.isElement(set[i]))  //if the element exists in both sets
			result = result + set[i];
	}
	return result;
}

// 5-) += operator  // unionize two sets into lhs 
const IntegerSet & IntegerSet :: operator += (const IntegerSet & rhs){
	IntegerSet result(*this);     //copy the lhs
	for(int i = 0; i < rhs.size; i++){
		if(! isElement(rhs.set[i]))         //if the ith element of rhs does not exist in lhs
			result = result + rhs.set[i];
	}
	*this = result;
	return *this;  
}
// returns the size of the set
int IntegerSet::GetSize() const{
	return size;
}

//returns the ith element of the set
int IntegerSet::GetElement(int i) const{
	return set[i];
}

//return true if the given int is an element of the set
bool IntegerSet::isElement(int x) const{
	bool isElement = false;
	for(int i = 0; i < size; i++){
		if (set[i] == x)
			isElement = true;
	}
	return isElement;
}

//free functions

// 1-) != operator // checking whether lhs and rhs are the same sets or not
bool operator != (const IntegerSet & lhs,const  IntegerSet & rhs){  
	bool equality = true;
	if(lhs.GetSize() != rhs.GetSize())  //if their size are different, then sets are obviously are not equal
		equality = false;
	else{
		for(int i = 0; i < lhs.GetSize(); i++){
			if(!(lhs.GetElement(i) <= rhs))
				equality = false;
		}
	}
	return !equality;
}

// 2-) << operator  // displaying the content of the set
ostream & operator << (ostream & os, const IntegerSet & set){
	cout << "{";
	if(set.GetSize() != 0){
		for(int i = 0; i < set.GetSize()-1; i++){
			cout << set.GetElement(i) << ", ";
		}
		cout << set.GetElement(set.GetSize()-1);
	}
	cout << "}";
	return os;  //to allow cascaded assignments
}

// 3-) <= operator // checks whether the integer is an element of the set or not
bool operator <= (int x, const IntegerSet & set){
	bool existence = false;
	for(int i = 0; i < set.GetSize(); i++){
		if(x == set.GetElement(i))
			existence = true;
	}
	return existence;
}

// 4-) <= operator // checks if the lhs is a subset of rhs
bool operator <= (const IntegerSet & lhs, const IntegerSet & rhs){
	bool subset = true;
	if(rhs.GetSize() < lhs.GetSize())  //if the size of lhs is greater than the size of rhs, then lhs is obviously not a subset of rhs
		subset = false;
	else{
		for(int i = 0; i < lhs.GetSize(); i++)
		if(!(lhs.GetElement(i) <= rhs))
			subset = false;
	}
	return subset;
}



