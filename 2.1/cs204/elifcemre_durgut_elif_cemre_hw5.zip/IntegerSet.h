//Elif Cemre Durgut - 26493 - Fifth Homework - CS204
//Header file

#ifndef _INTEGERSET_H_
#define _INTEGERSET_H_

#include <iostream>

using namespace std;

class IntegerSet
{
	public:
		IntegerSet();                                              // empty constructor
		IntegerSet(int);                                           // constructor with vector size
		IntegerSet(const IntegerSet &);                            // copy constructor
		~IntegerSet();                                             // destructor

		const IntegerSet & operator = (const IntegerSet & rhs);    //equalisation operator
		IntegerSet operator + (const IntegerSet & rhs) const;      //union operator to a set other than lhs and rhs
		IntegerSet operator + (int x);                     //adding an element operator                  
		IntegerSet operator * (const IntegerSet & rhs) const;      //intersection operator
		const IntegerSet & operator += (const IntegerSet & rhs);   //union operator to lhs
		int GetSize() const;                                       //returns size
		int GetElement(int) const;                                 //returns the element in the wanted index of set
		bool isElement (int) const;                                //checks the given integer if it is an element of the set


	private:
		int size;                                                  //number of elements in the set
		int * set;                                                 //array of set

};

//free functions prototypes

ostream & operator << (ostream & os, const IntegerSet & set);       //displaying operator
bool operator != (const IntegerSet & lhs, const IntegerSet & rhs);  //checks if the given sets are equal or not
bool operator <= (int x, const IntegerSet & set);                   //checks the given integer if it is an element of the set
bool operator <= (const IntegerSet & lhs, const IntegerSet & rhs);  //checks if the lhs is a subset of rhs


#endif