#include <iostream>
#include "CardList.h"
using namespace std;

CardList::CardList()
{
	head = NULL;
	tail = NULL;
}

bool CardList::existence(int month, int year){
	expirationNode * ptr = head;
	while (ptr != NULL)
	{
		if(ptr-> month == month && ptr-> year == year) {
			return true;
		}
		ptr = ptr->next;
	}
	return false;
}

bool CardList::cardExistence(string creditCardNo, int month, int year){
	expirationNode * ptr = head;
	while (ptr != NULL)
	{
		creditCardNode * ptr2 = ptr->cHead;
		while(ptr2 != NULL){
			if(ptr2->creditCardNo==creditCardNo && ptr->month==month && ptr->year==year){
				return true;
			}
			ptr2 = ptr2->next;
		}
		ptr = ptr->next;
	}
	return false;
}
void CardList::insertCard(string creditCardNo, int month, int year)
{
	expirationNode * ptr = head;
	if(cardExistence(creditCardNo, month, year))
		cout << creditCardNo << " " << month << " " << year << ": this card was already inserted " << endl;
	else if(!existence(month, year)){  
		creditCardNode * cardNode = new creditCardNode(creditCardNo, NULL); 
		cout << creditCardNo << " " << month << " " << year << ": added to a new expiration date node" << endl;
		if (head == NULL){ //if list is empty
			expirationNode * expNode = new expirationNode(month, year, cardNode, NULL, NULL);
			head = expNode;
			tail = head;	
		}
		else if(year < head->year || (year==head->year && month<head->month)){ //if the inserted card is the first node
			expirationNode * expNode = new expirationNode(month, year, cardNode, NULL, head);
			head->prev=expNode; 
			head = expNode;
		}
		else if(year > tail->year || (year == tail->year && month > tail->month)){ //if the inserted card is the last node
			expirationNode * expNode = new expirationNode(month, year, cardNode, tail, NULL);
			tail->next = expNode;
			tail = expNode;
		}
		else{
			while(ptr->next != NULL && (ptr->next->year < year || (ptr->next->year==year && month > ptr->next->month))){
				ptr = ptr->next;
			}
			expirationNode * expNode = new expirationNode(month, year, cardNode, ptr, ptr->next);
			ptr->next = expNode;
			ptr->next->next->prev=expNode;
		}
	}
	else{
		cout << creditCardNo << " " << month << " " << year << ": inserted to an existing expiration date node" << endl;
		expirationNode * ptr = head;
		while (ptr != NULL)
		{
			if(ptr-> month == month && ptr-> year == year) {
				creditCardNode * ptr2 = ptr->cHead; 
				while(ptr2->next!=NULL && creditCardNo > ptr2->next->creditCardNo){ 
					ptr2 = ptr2->next;
				}
				creditCardNode * cardNode = new creditCardNode(creditCardNo, ptr2->next); 
				ptr2->next = cardNode;
			}
			ptr = ptr->next;
		}
	}
}

void CardList::displayListChronological()
{
	expirationNode * ptr = head;
	if(ptr==NULL){
		cout << "\nList is empty!\n" << endl;
	}
	else {
		while (ptr != NULL) 
		{
			cout << "Expiration Date: " << ptr ->month << " " << ptr->year << endl;
			int i = 0;
			creditCardNode * ptr2 = ptr->cHead;
			while(ptr2 != NULL){
				cout << i+1 << ") " << ptr2->creditCardNo << endl;
				ptr2 = ptr2->next;
				i++;
			}
			ptr = ptr->next;
			cout << "-------------------\n" << endl;
		}
	}
}
//Begin: Code taken from DoublyLinkedList.cpp and modified
void CardList::displayListReverseChronological()
{
	expirationNode * ptr = tail;
	if(tail==NULL){
		cout << "\nList is empty!\n" << endl;
	}
	else {
		while (ptr != NULL) 
		{
			cout << "Expiration Date: " << ptr ->month << " " << ptr->year << endl;
			int i = 1; 
			creditCardNode * ptr2 = ptr->cHead;
			while(ptr2 != NULL){
				cout << i << ") " << ptr2->creditCardNo << endl;
				i++;
				ptr2 = ptr2->next;
			}
			ptr = ptr->prev;  
			cout << "-------------------\n" << endl;
		}
	}
}
//End: Code taken from DoublyLinkedList.cpp and modified
void CardList::cardSearch (string creditCardNo)
{
	bool cardExistence = false;
	expirationNode *  ptr = head; 
	while (ptr != NULL)
	{
		creditCardNode * ptr2 = ptr->cHead;
		while(ptr2 != NULL){
			if(ptr2->creditCardNo==creditCardNo){
				cout << "\nThere exists a credit card given number " << creditCardNo << " with expiration date: " << ptr->month << " " << ptr->year <<"\n" << endl;
				cardExistence = true;
			}
			ptr2 = ptr2->next;
		}
		ptr = ptr->next;
	}
	if (!cardExistence){
		cout << "\nThere is no credit card with given credit card number: " << creditCardNo << "\n" << endl;
	}
}

void CardList::bulkDelete (int month, int year) 
{
	expirationNode *  ptr; 
	while (head!=NULL && (year > head->year || (year == head->year && month >= head->month)))
	{
		cout << "Node with expiration date " << head->month << " " << head->year <<" and the following credit cards have been deleted!" << endl;
		int i = 0;
		while(head->cHead != NULL){
			creditCardNode * ptr2=head->cHead;
			cout << i+1 << ") " << ptr2->creditCardNo << endl;
			i++;
			head->cHead = ptr2->next;
			delete ptr2;
		}
		ptr = head;
		head = head->next;
		if(ptr != tail)
			head->prev=NULL;
		else
			tail=NULL;
		delete ptr;
	}
	
}
//Begin: Code taken from linkedList.cpp
void CardList::deleteAll ()  
{
	expirationNode *ptr;
	while(head!=NULL)
	{
		while(head->cHead != NULL)
		{
			creditCardNode * ptr2 = head->cHead;
			head->cHead = ptr2->next;
			delete ptr2;
		}
		ptr=head;
		head=head->next;
		delete ptr;
	}
}
//End: Code taken from linkedList.cpp
