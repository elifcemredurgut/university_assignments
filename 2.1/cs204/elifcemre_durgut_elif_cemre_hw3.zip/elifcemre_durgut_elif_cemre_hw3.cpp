/*  Elif Cemre Durgut - 26493 - Third Homework - CS204
This homework stores blacklisted credit cards and does some operations according to user's option.
12/03/2020 
*/ 

#include <iostream>
#include <string>
#include <sstream>          
#include <fstream>           
#include <vector>
#include "CardList.h"

using namespace std;

bool CardNumberCheck(string card){  //It checks whether the input card number is valid
	for(int i=0; i<card.size(); i++){
		if(card.at(i)<'0'|| card.at(i)>'9'){
			return false;
		}
	}
	return true;
}

int main(){
	CardList CardList;
	int option, inputmonth, inputyear, filemonth, fileyear;
	string inputcard, cardnumber;
	string fileName, line;
	ifstream input;
	do{
		cout << "\n1) Upload Card(s) from a File \n2) Display List Chronological \n3) Display List Reverse Chronological \n4) Card Search \n5) Bulk Delete \n6) Exit" << endl;
		cout << "Please choose option from the menu: ";
		cin >> option;
		if(option==1){
				cout << "Please enter file name: ";
				cin >> fileName;
				cout << endl;
				input.open(fileName);
				if(input.fail()){
					cout << "Could not find a file named " << fileName << "\n" << endl;
					cin.clear();
					cin.ignore(60,'\n');
				}
				else{
					while(getline(input, line)){
						istringstream strStream(line);
						strStream >> cardnumber >> filemonth >> fileyear;
						CardList.insertCard(cardnumber, filemonth, fileyear);
					}
					input.clear(); //to be able to go to the beginning of the file
					input.seekg(0);
					input.close();
				}
		}
		else if(option==2){
			CardList.displayListChronological();
		}
		else if(option==3){
			CardList.displayListReverseChronological();
		}
		else if(option==4){
			cout << "Please enter the credit card number: ";
			cin >> inputcard;
			if(inputcard.size()==16 && CardNumberCheck(inputcard)){
				CardList.cardSearch(inputcard);
			}
			else
				cout <<"\nInvalid format!\n" << endl;
		}
		else if(option==5){
			cout << "Please enter month and year: ";
			cin >> inputmonth >> inputyear;
			if(cin.fail() || inputmonth>12 || inputmonth<1) { 
					cout << "\nInvalid Date!\n" << endl;
					cin.clear();
					cin.ignore(60,'\n'); //It ignores first 60 characters or until '\n' --> Reference: A Computer Science Tapestry, 1999, page:727 
			}
			else
				CardList.bulkDelete(inputmonth, inputyear);
		}
		else if(option==6){
			cout << "All the nodes have been deleted!" << endl;
			cout << "Terminating!!!" << endl;
			CardList.deleteAll();
		}
		else{
			cout << "\nInvalid Operation!\n" << endl;
			cin.clear();
			cin.ignore(60,'\n');
		}
	}while(option!=6);

	return 0;
}