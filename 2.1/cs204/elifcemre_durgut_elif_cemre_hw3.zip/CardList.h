
#ifndef _CARDLIST_H
#define _CARDLIST_H

#include <string>

using namespace std;

struct creditCardNode
{  
	string creditCardNo;  
	creditCardNode * next;    

	creditCardNode::creditCardNode ()
	{}
	creditCardNode::creditCardNode(string creditCardNo, creditCardNode * linkNext)
		: creditCardNo(creditCardNo), next(linkNext)
	{}
};

struct expirationNode
{
	int month, year;  
	creditCardNode * cHead;  
	expirationNode * next;  
	expirationNode * prev; 
	
	expirationNode::expirationNode()
	{}
	expirationNode::expirationNode(int month, int year, creditCardNode * linkCard, expirationNode * linkPrev, expirationNode * linkNext)
		: month(month), year(year), cHead(linkCard), prev(linkPrev), next(linkNext)
	{}
};

class CardList  
{ 
public:  
	CardList(); //default constructor that creates an empty list  
	void insertCard (string creditCardNo, int month, int year);    //inserts a new card to the structure in sorted fashion  
	void displayListChronological ();  //displays entire structure in chronological order  
	void displayListReverseChronological ();  //displays entire structure in reverse chronological order  
	void cardSearch (string creditCardNo);  //displays all of the occurrences of the given card number  
	void bulkDelete (int month, int year);  //deletes all nodes up to and including given expiration date  
	void deleteAll (); //deletes the entire structure 
	//Additional ones
	bool existence(int month, int year);  //searches for whether there is an existing node with given month and year
	bool cardExistence(string creditCardNo, int month, int year); //searches for whether there is an existing node with given, card number, month and year
private:  
	expirationNode * head;  
	expirationNode * tail; 

};

#endif