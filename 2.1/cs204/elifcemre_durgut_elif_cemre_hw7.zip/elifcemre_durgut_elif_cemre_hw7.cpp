/*Elif Cemre Durgut - 26493 - 7th Homework - CS204
This homework encrypts given data according to the given key.
01/05/2020*/

#include <iostream>
#include <string>

using namespace std;

int main(){
	
	string plaintext, key;
	
	cout << "*** Welcome to the Simple Data Encryption Application ***" << endl;
	cout << "Please enter the encryption key: ";
	getline(cin, key);
	cout << "Please enter the plaintext to be encrypted: ";

	while(getline(cin, plaintext)){  //It will continue until user enters ^Z
		cout << "Ciphertext: ";
		for (int i = 0; i < plaintext.length(); i++)   //for every character in plaintext string
		{
			unsigned char mask=0x01;            //an unsigned char to control whether the plaintext[i]'s nth bit is 1 or not
			unsigned char c = (unsigned)0x00;   //char to be modified and displayed
			for (int j=0; j<8; j++){            //8 times - because char contains 1 byte = 8 bits
				if (plaintext[i] & mask) {
					if(j==0)                    //PERMUTATION ALGORITHM
						c = c| 0x04;        //move the 0th bit to the 2nd bit (0-->2)
					else if(j==1)
						c = c | 0x01;       //1-->0
					else if(j==2)
						c = c | 0x08;       //2-->3
					else if(j==3)
						c = c | 0x02;       //3-->1
					else if(j==4)
						c = c | 0x40;       //4-->6
					else if(j==5)
						c = c | 0x10;       //5-->4  
					else if(j==6)
						c = c | 0x80;       //6-->7
					else if(j==7)
						c = c | 0x20;	    //7-->5
				}
				mask = mask << 1;  //shift to the left to check other bits
			}
			c = c ^ (unsigned)key[i%key.length()];  //to be able to use the key consecutively
			cout << hex << (int) c;   //print the char c in hexadecimal format
		}
		cout << endl;
		cout << "\nPlease enter the plaintext to be encrypted: ";
	}
	return 0;
}