#ifndef _CAMERA_TEST_H
#define _CAMERA_TEST_H
int run_camera_tests(void);
#endif