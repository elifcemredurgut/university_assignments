﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace ProjectStep1Server
{
    public partial class Form_server : Form
    {
        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        List<Socket> clientSockets = new List<Socket>(); //list that keeps client sockets
        List<string> userNames = new List<string>(); //list that keeps the list of usernames
        List<string> connectedUsers = new List<string>();//to keep track of connected users

        int counter = 0;
        //string userDb = "C:\\Users\\suuser\\Desktop\\user-db.txt";
        //string sweetsDb = "C:\\Users\\suuser\\Desktop\\sweetdatabase.txt";

        string userDb = "C:\\Users\\elifc\\Downloads\\user-db.txt";
        string sweetsDb = "C:\\Users\\elifc\\Downloads\\sweetdatabase.txt";
        string followDb = "C:\\Users\\elifc\\Downloads\\follow.txt";
        string blockDb = "C:\\Users\\elifc\\Downloads\\block.txt";

        //string userDb = "C:\\Users\\HP\\Documents\\Online Courses\\cs408\\user-db.txt";
        //string sweetsDb = "C:\\Users\\HP\\Documents\\Online Courses\\cs408\\sweetdatabase.txt";
        //string followDb = "C:\\Users\\HP\\Documents\\Online Courses\\cs408\\follow.txt";
        //string blockDb = "C:\\Users\\HP\\Documents\\Online Courses\\cs408\\block.txt";

        //string userDb = "C:\\Users\\elifc\\Downloads\\cs408\\projectStep1\\user-db.txt";
        //string sweetsDb = "C:\\Users\\elifc\\Downloads\\cs408\\projectStep1\\sweetdatabase.txt";

        bool terminating = false;
        bool listening = false;
        

        public Form_server()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form_server_FormClosing);
            InitializeComponent();

            foreach (string line in File.ReadLines(@userDb))
            {
                userNames.Add(line);
                counter++;
            }
        }

        private void Form_server_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (connectedUsers.Count() > 0) {
                Byte[] reportBuffer = Encoding.Default.GetBytes("CLOSE_");
                foreach(Socket s in clientSockets) {
                    s.Send(reportBuffer);
                    Console.WriteLine("closing message");
                }
            }
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }
        private void Accept()
        {
            Console.WriteLine(listening);
            while (listening)
            {
                try
                {
                    Socket newClient = serverSocket.Accept(); //create a socket for new connection
                    Byte[] username_buffer = new Byte[1024];
                    newClient.Receive(username_buffer); //receive the username of the client

                    string receivedUserName = Encoding.Default.GetString(username_buffer);
                    receivedUserName = receivedUserName.Substring(0, receivedUserName.IndexOf("\0"));


                    if (userNames.Contains(receivedUserName)) // if the username exists in given user-database
                    {
                        if (connectedUsers.Contains(receivedUserName)) //if the username is alreadu connected
                        {
                            logs.AppendText(DateTime.Now + " Client " + receivedUserName + " is already connected\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + connectedUsers.Count + "\n");
                            //report to the client
                            Byte[] reportBuffer = Encoding.Default.GetBytes("ERROR" + "Client " + receivedUserName + " is already connected\n");
                            newClient.Send(reportBuffer);

                            newClient.Close();

                        }
                        else
                        {
                            clientSockets.Add(newClient);  // add the client to the client sockets
                            connectedUsers.Add(receivedUserName); //add the client to connected clients' list

                            logs.AppendText(DateTime.Now + " Client " + receivedUserName + " is connected\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + connectedUsers.Count + "\n");

                            Byte[] reportBuffer = Encoding.Default.GetBytes("OK");
                            newClient.Send(reportBuffer);

                            Thread receivedThread = new Thread(() => Receive(newClient, receivedUserName));
                            receivedThread.Start();
                        }
                    }
                    else
                    {
                        logs.AppendText(DateTime.Now + "Client " + receivedUserName + " is not registered!\n"); //if the username is not from the users-db
                        Byte[] reportBuffer = Encoding.Default.GetBytes("ERRORThis username does not exist in database\n");
                        newClient.Send(reportBuffer);

                        newClient.Close();
                    }
                }
                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText(DateTime.Now + " Socket stopped\n");
                        textBox_port.Enabled = true;
                        button_listen.Enabled = true;
                        listening = false;
                    }
                }
            }
        }
        private void Receive(Socket thisClient, string username)
        {
            bool connected = true;
            while (connected && !terminating)
            {
                try
                {
                    Byte[] sweet_buffer = new Byte[1024];
                    thisClient.Receive(sweet_buffer);

                    string request = Encoding.Default.GetString(sweet_buffer);
                    request = request.Substring(0, request.IndexOf("\0"));
                    Console.WriteLine("the request is:");
                    Console.WriteLine(request);
                    string sweet;
                    if (request.Length > 10 && request.Substring(0, 7) == "follow-")
                    {
                        string username1 = request.Substring(7, request.IndexOf("-", 7) - 7);
                        Console.Write(username1);
                        string username2 = request.Substring(request.IndexOf("-", 7) + 1);
                        Console.Write(username2);
                        if (username1 == username2)
                        {
                            logs.AppendText(DateTime.Now + " User can't follow herself/himself\n");
                            Byte[] errorBuffer = Encoding.Default.GetBytes("ERRORUser can't follow herself/himself");
                            try
                            {

                                thisClient.Send(errorBuffer);
                            }
                            catch
                            {
                                Console.WriteLine("Problem sendingg!");
                            }
                        }
                        else if (!userNames.Contains(username2))
                        {
                            //check if the user2 exists in the database
                            logs.AppendText(DateTime.Now + username2 + " not found!\n");
                            Byte[] errorBuffer = Encoding.Default.GetBytes("ERROR" + username2 + "not found");
                            try
                            {

                                thisClient.Send(errorBuffer);
                            }
                            catch
                            {
                                Console.WriteLine("Problem sendingg username not found!");
                            }
                        }
                        else
                        {
                            //check if user1 was blocked by user2
                            bool foundBlock = false;
                            var f = File.ReadLines(@blockDb);
                            Console.WriteLine("Check if user1 was blocked yb user2");
                            foreach (var line in f)
                            {
                                string usr = username2 + '&' + username;
                                Console.WriteLine("here");
                                Console.WriteLine(usr);
                                if (line.IndexOf(usr) == 0)
                                {
                                    Console.WriteLine("here2");
                                    logs.AppendText(DateTime.Now + " Client " + username1 + " is blocked by " + username2 + ", can't follow!\n");
                                    Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + username + " can't follow " + username2 + ", because he/she is blocked by "+ username2+ "!\n");
                                    try
                                    {

                                        thisClient.Send(errBuffer);
                                        foundBlock = true;
                                    }
                                    catch (Exception ex)
                                    {
                                        System.Console.WriteLine(ex.StackTrace);
                                    }
                                }
                            }
                            if (!foundBlock)
                            {
                                //follow 
                                string myfile = @followDb;
                                bool found = false;
                                var fll = File.ReadLines(@followDb);
                                foreach (var line in fll)
                                {
                                    string usr = username + ':' + username2;
                                    if (line.IndexOf(usr) == 0)
                                    {
                                        logs.AppendText(DateTime.Now + " Client " + username1 + " already follows " + username2 + "\n");
                                        Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + username + " already follows " + username2 + "\n");
                                        try
                                        {

                                            thisClient.Send(errBuffer);
                                            found = true;
                                        }
                                        catch (Exception ex)
                                        {
                                            System.Console.WriteLine(ex.StackTrace);
                                        }
                                    }
                                }
                                if (found == false)
                                {
                                    // Appending the given texts

                                    using (StreamWriter sw = File.AppendText(myfile))
                                    {
                                        string new_line = username1 + ':' + username2;
                                        sw.WriteLine(new_line);
                                        Byte[] userFollowed = Encoding.Default.GetBytes("ERROR " + username + " followed " + username2);
                                        try
                                        {

                                            thisClient.Send(userFollowed);
                                            logs.AppendText(DateTime.Now + " Client " + username1 + " has followed " + username2 + "\n");
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Problem following the user!");
                                        }

                                    }
                                }


                            }


                        }
                    }
                    else if (request.Length >= 7 && request.Substring(0, 7) == "delete-")
                    {
                        logs.AppendText(DateTime.Now + " " + username + " requested to delete a sweet.\n");

                        string IDToDelete = request.Substring(request.IndexOf("-") + 1);

                        var lines = File.ReadLines(@sweetsDb);
                        int lineNum = 0;
                        string sweet_feed = "";

                        bool toDelete = false;
                        bool notOwner = false;

                        foreach (var line in lines)
                        {
                            if (lineNum > 0)
                            {

                                string usernameData = line.Substring(0, line.IndexOf(" "));
                                string substring_line = line.Substring(line.IndexOf(" ") + 1);
                                string sweet_id = substring_line.Substring(0, substring_line.IndexOf(" "));
                                string substring_line2 = substring_line.Substring(substring_line.IndexOf(" ") + 1);

                                if (sweet_id == IDToDelete && username == usernameData)
                                {
                                    toDelete = true;
                                }
                                else
                                {
                                    if (sweet_id == IDToDelete && username != usernameData)
                                    {
                                        notOwner = true;

                                        Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORThis sweet does not belong to you!");
                                        try
                                        {

                                            thisClient.Send(userlistBuffer);
                                            logs.AppendText(DateTime.Now + " " + username + " tried to delete someone's sweet.\n");
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Problem sending ownership error!");
                                        }
                                    }
                                    sweet_feed += usernameData + " " + sweet_id + " " + substring_line2 + "\n";
                                }


                            }
                            lineNum++;
                        }
                        if (toDelete)
                        {
                            System.IO.File.WriteAllText(@sweetsDb, "SWEET DATABASE\n" + sweet_feed);
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORYour sweet is deleted!");
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " " + username + " delete is successful.\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending successful delete!");
                            }
                        }
                        else if (!notOwner)
                        {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORThere is no such sweet!");
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " " + username + " there is no such sweet.\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending invalid delete id!");
                            }
                        }
                    }
                    else if (request.Length >= 10 && request.Substring(0, 6) == "block-")
                    {
                        string usernameToBlock = request.Substring(6);
                        Console.WriteLine("username: ");
                        Console.WriteLine(usernameToBlock);
                        if (username == usernameToBlock) //USERNAME == USERNAMETOBLOCK
                        {

                            Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + "You tried to block yourself! This action is not possible!\n");

                            try
                            {

                                thisClient.Send(errBuffer);
                                logs.AppendText(DateTime.Now + username + " tried to block themselves!\n");

                            }
                            catch (Exception ex)
                            {
                                System.Console.WriteLine(ex.StackTrace);
                            }
                        }else
                        {

                            if (userNames.Contains(usernameToBlock))
                            {
                                //CHECK IF  USER HAS ALREADY BLOCKED THE USERNAMETOBLOCK
                                bool wasBlocked = false;
                                var lst = File.ReadLines(@blockDb);

                                foreach (var line in lst)
                                {
                                    if (line.IndexOf(username + '&' + usernameToBlock) == 0)
                                    {
                                        //USER HAS ALREADY BEEN BLOCKED
                                        Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + usernameToBlock + " is already blocked!\n");

                                        try
                                        {
                                            wasBlocked = true;
                                            thisClient.Send(errBuffer);
                                            logs.AppendText(DateTime.Now + username + " tried to block " + usernameToBlock + " which was already blocked!\n");

                                        }
                                        catch (Exception ex)
                                        {
                                            System.Console.WriteLine(ex.StackTrace);
                                        }
                                    }
                                }
                                if (!wasBlocked)
                                {
                                        //BLOCK THE USER
                                        string myfile = @blockDb;
                                        using (StreamWriter sw = File.AppendText(myfile))
                                        {
                                            string new_line = username + '&' + usernameToBlock;
                                            sw.WriteLine(new_line);
                                            Console.Write(new_line);
                                            Byte[] userBlocked = Encoding.Default.GetBytes("ERROR " + username + " blocked " + usernameToBlock);
                                            try
                                            {

                                                thisClient.Send(userBlocked);
                                                logs.AppendText(DateTime.Now + " Client " + username + " has blocked " + usernameToBlock + "\n");

                                                //CHECK IF USERNAMETOBLOCK FOLLOWS USERNAME
                                                string followFile = @followDb;
                                                string updatedFile = "";
                                                bool found_follower = false;
                                                var fll = File.ReadLines(@followDb);
                                                foreach (var linee in fll)
                                                {

                                                    string usr = usernameToBlock + ':' + username;
                                                    if (linee.IndexOf("BLOCK DATABASE") != 0)
                                                    {

                                                        if (linee.IndexOf(usr) == 0)
                                                        {
                                                            found_follower = true;
                                                        }
                                                        else
                                                        {
                                                            updatedFile += linee + '\n'; //TO-DO: check if new line is needed
                                                        }
                                                    }

                                                }
                                                if (found_follower)
                                                {
                                                    //UPDATE THE FILE
                                                    Console.Write(updatedFile);
                                                    File.WriteAllText(followDb, updatedFile);
                                                }
                                            }
                                            catch
                                            {
                                                Console.WriteLine("Problem blocking the user!");
                                            }

                                        }
                                        
                                }

                            }
                            else
                            {
                                Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + usernameToBlock + " does not exist!\n");

                                try
                                {

                                    thisClient.Send(errBuffer);
                                    logs.AppendText(DateTime.Now + username + " tried to block " + usernameToBlock + " which does not exist!\n");

                                }
                                catch (Exception ex)
                                {
                                    System.Console.WriteLine(ex.StackTrace);
                                }
                            }
                        }

                    }
                    else if (request == "following")
                    {
                        logs.AppendText(DateTime.Now + " " + username + " requested followings list\n");
                        string text = "";

                        var lst = File.ReadLines(@followDb);

                        foreach (var line in lst)
                        {
                            if (line.IndexOf(username) == 0)
                            {
                                int idx = line.IndexOf(':') + 1;
                                string followinguser = line.Substring(idx);
                                text += followinguser + "\n";
                            }
                        }
                        if (text == "")
                        {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORYou don't follow anyone!");
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " " + username + " has no followings to send\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending followings list!");
                            }
                        }
                        else {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("fwing" + text);
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " followings list has been sent to " + username + "\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending followings list!");
                            }
                        }
                        
                    }
                    else if (request == "follower")
                    {
                        logs.AppendText(DateTime.Now + " " + username + " requested followers list\n");
                        string text = "";

                        var lst = File.ReadLines(@followDb);

                        foreach (var line in lst)
                        {
                            if (line.IndexOf(username) > 0)
                            {
                                int idx = line.IndexOf(':');
                                string followinguser = line.Substring(0,idx);
                                text += followinguser + "\n";
                            }
                        }
                        if (text == "")
                        {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORYou don't have any followers!");
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " "+ username + " has no followers to send\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending followers list!");
                            }
                        }
                        else
                        {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("fwers" + text);
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " followers list has been sent to " + username + "\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending followers list!");
                            }
                        }
                    }
                    else if (request == "mysweets")
                    {
                        logs.AppendText(DateTime.Now + " " + username + " requested his/her sweets\n");
                        var lines = File.ReadLines(@sweetsDb);
                        int lineNum = 0;
                        string sweet_feed = "";


                        foreach (var line in lines)
                        {
                            if (lineNum > 0)
                            {

                                string usernameData = line.Substring(0, line.IndexOf(" "));
                                string substring_line = line.Substring(line.IndexOf(" ") + 1);
                                string sweet_id = substring_line.Substring(0, substring_line.IndexOf(" "));

                                string substring_line2 = substring_line.Substring(substring_line.IndexOf(" ") + 1);
                                string time_ = substring_line2.Substring(0, substring_line2.IndexOf("*"));

                                string sweet_ = substring_line2.Substring(substring_line2.IndexOf("*") + 1);

                                if (username == usernameData) //only sweets that belong to that username
                                {
                                    sweet_feed += username + "\t" + sweet_id + "\t" + time_ + '\t' + sweet_ + "\n";
                                }

                            }
                            lineNum++;
                        }
                        if(sweet_feed == ""){
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("ERRORYou don't have any sweets!");
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " " + username + " has no sweets to send\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending sweets list!");
                            }
                        }
                        else
                        {
                            Byte[] userlistBuffer = Encoding.Default.GetBytes("mysws" + sweet_feed);
                            try
                            {

                                thisClient.Send(userlistBuffer);
                                logs.AppendText(DateTime.Now + " his/her sweets list has been sent to " + username + "\n");
                            }
                            catch
                            {
                                Console.WriteLine("Problem sending sweets list!");
                            }
                        }
                    }
                    else if (request == "users")
                    {
                        // Read entire text file content in one string.
                        string text = File.ReadAllText(@userDb);
                        text = text.Substring(text.IndexOf('\n') + 1);
                        Console.WriteLine(text);
                        logs.AppendText(DateTime.Now + " " + username + " requested user list\n");


                        Byte[] userlistBuffer = Encoding.Default.GetBytes("users" + text);
                        try
                        {

                            thisClient.Send(userlistBuffer);
                            logs.AppendText(DateTime.Now + " user list has been sent to " + username + "\n");
                        }
                        catch
                        {
                            Console.WriteLine("Problem sending user list!");
                        }
                    }
                    else if (request == "sweef")
                    {
                        List<string> userFollowing = new List<string>(); //list that keeps the list of usernames

                        var lst = File.ReadLines(@followDb);

                        foreach (var line in lst)
                        {
                            if (line.IndexOf(username) == 0)
                            {
                                int idx = line.IndexOf(':') + 1;
                                string followinguser = line.Substring(idx);
                                userFollowing.Add(followinguser);
                            }
                        }
                        //send the sweets of the followings
                        var sweetList = File.ReadLines(@sweetsDb);
                        //  List<string> followingSweets = new List<string>(); //list that keeps the list of usernames
                        string followingSweets = "";
                        if (userFollowing.Count != 0)
                        {
                            foreach (var line in sweetList)
                            {
                                string sweetUser = line.Substring(0, line.IndexOf(" "));
                                if (userFollowing.Contains(sweetUser))
                                {
                                    //followingSweets.Add(line);
                                    string usernameq = line.Substring(0, line.IndexOf(" "));
                                    string substring_line = line.Substring(line.IndexOf(" ") + 1);
                                    string sweet_id = substring_line.Substring(0, substring_line.IndexOf(" "));

                                    string substring_line2 = substring_line.Substring(substring_line.IndexOf(" ") + 1);
                                    string time_ = substring_line2.Substring(0, substring_line2.IndexOf("*"));

                                    string sweet_ = substring_line2.Substring(substring_line2.IndexOf("*") + 1);


                                    string sweet_f = usernameq + "\t" + sweet_id + "\t" + time_ + '\t' + sweet_ + "\n";

                                    followingSweets += sweet_f;
                                }
                            }
                            if (followingSweets == "")
                            {
                                Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + "users that " + username + " follows have no sweet\n");

                                try
                                {

                                    thisClient.Send(errBuffer);
                                    logs.AppendText(DateTime.Now + " users that " + username + " follows have no sweet\n");

                                }
                                catch (Exception ex)
                                {
                                    System.Console.WriteLine(ex.StackTrace);
                                }
                            }
                            else
                            {
                                Byte[] followSweetBuffer = Encoding.Default.GetBytes("sweef" + followingSweets);

                                try
                                {

                                    thisClient.Send(followSweetBuffer);
                                    logs.AppendText(DateTime.Now + " all sweets of the users " + username + " follows have been sent!\n");
                                    Console.WriteLine(followingSweets);
                                }
                                catch (Exception ex)
                                {
                                    System.Console.WriteLine(ex.StackTrace);
                                }
                            }

                        }
                        else
                        {
                            Byte[] errBuffer = Encoding.Default.GetBytes("ERROR " + username + " does not follow anyone\n");
                            try
                            {

                                thisClient.Send(errBuffer);
                                logs.AppendText(DateTime.Now + " " + username + " does not follow anyone\n");

                            }
                            catch (Exception ex)
                            {
                                System.Console.WriteLine(ex.StackTrace);
                            }
                        }
                    }
                    else if (request.Length > 11)
                    {
                        string keyword = request.Substring(0, 11);  //server and client agrees on a keyword
                        if (keyword == "gkegcs40818")
                        {
                            sweet = request.Substring(11, request.Length - 11);
                            PostSweet(thisClient, username, sweet);
                        }
                    }
                    else if (request.Length == 11 && request == "gkegcs40818")
                    {//get sweet feed
                        SendSweetFeed(thisClient, username);
                        logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count) + "\n");
                    }
                    else if (request.Length >= 12 && request.Substring(0, 12) == "Disconnected")
                    {
                        Console.WriteLine("disconnect");
                        if (!terminating)
                        {
                            logs.AppendText(DateTime.Now + " Client " + username + " has disconnected.\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count - 1) + "\n");
                        }
                        thisClient.Close(); //close socket connection 
                        clientSockets.Remove(thisClient); //remove from the socket list
                        connectedUsers.Remove(username); //remove from the connected users' list
                        connected = false;
                    }
                }
                catch (Exception e)
                {
                    
                    Console.WriteLine(e);
                    if (!terminating)
                    {
                        logs.AppendText(DateTime.Now + " Client " + username + " has disconnected.\n");
                        logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count - 1) + "\n");
                    }
                    thisClient.Close(); //close socket connection 
                    clientSockets.Remove(thisClient); //remove from the socket list
                    connectedUsers.Remove(username); //remove from the connected users' list
                    connected = false;
                }

            }
        }
        private int getID()
        {
            string lastLine = "";
            int unique_id;
            var lst = File.ReadLines(@sweetsDb);
            foreach (var line in lst)
            {
                lastLine = line;
            }

            
            if (lastLine == "SWEET DATABASE" || (lastLine == "" && lst.Count() == 2))
            {
                return 0;
            }
            else
            {
                string substring_line = lastLine.Substring(lastLine.IndexOf(" ") + 1);
                unique_id = Int32.Parse(substring_line.Substring(0, substring_line.IndexOf(" ")));
            }
            return unique_id + 1;

        }
        private void PostSweet(Socket thisClient, string username, string sweet)
        {
            int unique_id = getID();
            string new_sweet = username + " " + unique_id + " " + DateTime.Now + "*" + sweet;

            // Creating a file
            string myfile = @sweetsDb;

            // Appending the given texts
            using (StreamWriter sw = File.AppendText(myfile))
            {
                sw.WriteLine(new_sweet);
            }

            logs.AppendText(DateTime.Now + " sweet by " + username + " was posted\n");
        }
        private void SendSweetFeed(Socket thisClient, string clientUsername)
        {
            if (!terminating)
            {
                try
                {
                    var lines = File.ReadLines(@sweetsDb);
                    int lineNum = 0;
                    string sweet_feed = "";
                    //long size_Int = new System.IO.FileInfo(@sweetsDb).Length;
                    //string size = "length" + size_Int.ToString();
                    //List<string> dontSendSweetsofTheseUsernames = new List<string>();
                   

                    foreach (var line in lines)
                    {
                        if (lineNum > 0)
                        {
                            
                            string username = line.Substring(0, line.IndexOf(" "));
                            bool dontSend = false;
                            var f = File.ReadLines(@blockDb);
                            foreach (var linee in f)
                            {
                                string usr= username+ '&' + clientUsername;
                                Console.WriteLine(usr);
                                if (linee.IndexOf(usr) == 0)
                                {
                                    Console.WriteLine("Dont send");
                                    Console.WriteLine(usr);
                                    dontSend = true;
                                }
                            }
                            if (!dontSend)
                            {
                                string substring_line = line.Substring(line.IndexOf(" ") + 1);
                                string sweet_id = substring_line.Substring(0, substring_line.IndexOf(" "));

                                string substring_line2 = substring_line.Substring(substring_line.IndexOf(" ") + 1);
                                string time_ = substring_line2.Substring(0, substring_line2.IndexOf("*"));

                                string sweet_ = substring_line2.Substring(substring_line2.IndexOf("*") + 1);

                                if (username != clientUsername) //user's own sweets shouldnt be added to sweet feed
                                {
                                    sweet_feed += username + "\t" + sweet_id + "\t" + time_ + '\t' + sweet_ + "\n";
                                }

                            }

                        }
                        lineNum++;
                    }
                    if (sweet_feed.Length == 0)
                    {
                        Console.WriteLine("no sweet");
                        sweet_feed = "ERRORNo sweets yet!";
                        Byte[] retBuffer = Encoding.Default.GetBytes(sweet_feed);
                        try
                        {

                            thisClient.Send(retBuffer);
                            logs.AppendText(DateTime.Now + " All the sweets by other users have been sent to " + clientUsername + "\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count) + "\n");
                        }
                        catch (Exception e)
                        {
                            System.Console.WriteLine(e.StackTrace);
                            //logs.AppendText("catch");
                        }
                    }
                    else
                    {
                        sweet_feed = sweet_feed.Substring(0, sweet_feed.Length - 1);
                        Byte[] sizeBuffer = Encoding.Default.GetBytes("length"+sweet_feed.Length.ToString());
                        Console.WriteLine(sweet_feed.Length.ToString());
                        try
                        {

                            thisClient.Send(sizeBuffer);
                            Byte[] retBuffer = Encoding.Default.GetBytes(sweet_feed);
                            try
                            {

                                thisClient.Send(retBuffer);
                                logs.AppendText(DateTime.Now + " All the sweets by other users have been sent to " + clientUsername + "\n");
                                logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count) + "\n");
                            }
                            catch (Exception e)
                            {
                                System.Console.WriteLine(e.StackTrace);
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Problem sendingg!");
                        }
                    }
                }
                catch (Exception e)
                {
                    Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + "Server couldn't send the list of sweets");
                    try
                    {

                        thisClient.Send(errBuffer);
                    }
                    catch (Exception ex)
                    {
                        System.Console.WriteLine(ex.StackTrace);
                    }
                    logs.AppendText(DateTime.Now + " Error while sending the list of sweets!\n");
                }
            }
        }


        private void button_listen_Click(object sender, System.EventArgs e)
        {
            int serverPort;


            if (Int32.TryParse(textBox_port.Text, out serverPort)) //if the portnumber is provided correctly
            {
                listening = true;

                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);

                serverSocket.Bind(endPoint);
                serverSocket.Listen(counter); //counter is maximum number of clients 

                button_listen.Enabled = false;
                textBox_port.Enabled = false;



                if (!File.Exists(@sweetsDb))
                {
                    File.WriteAllText(@sweetsDb, "SWEET DATABASE\n");
                }
                if (!File.Exists(@followDb))
                {
                    File.WriteAllText(@followDb, "FOLLOW DATABASE\n");
                }
                if (!File.Exists(@blockDb))
                {
                    File.WriteAllText(@blockDb, "BLOCK DATABASE\n");
                }

                Thread acceptThread = new Thread(Accept);
                acceptThread.Start();


                logs.AppendText("Started listening\n");
            }
            else
            {
                logs.AppendText("Please, check the port number!\n");
            }
        }

        private void logs_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void textBox_port_TextChanged(object sender, System.EventArgs e)
        {

        }

    }
}