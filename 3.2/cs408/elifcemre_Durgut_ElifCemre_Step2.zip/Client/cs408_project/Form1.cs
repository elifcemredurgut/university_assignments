﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace cs408_project  //client side
{
    public partial class Form1 : Form
    {

        bool terminating = false;
        bool connected = false;
        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            //TCP connection
            Console.WriteLine("new connect");
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = textBox_ip.Text;

            int portNum;
            if (Int32.TryParse(textBox_port.Text, out portNum))
            {
                try
                {
                    //connect
                    clientSocket.Connect(IP, portNum);
                    connected = true;

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();
                    

                    //send username
                    string username = textBox_username.Text;
                    Byte[] buffer = Encoding.Default.GetBytes(username);
                    clientSocket.Send(buffer);

                }
                catch
                {
                    logs.AppendText("\nCould not connect to the server!\n");
                }
            }
            else
            {
                logs.AppendText("\nCheck the port number!\n");
            }
        }

        private void Receive()
        {
            while (connected)
            {
                try
                {
                    //receive incoming message
                    Byte[] buffer = new Byte[4096];  
                    clientSocket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    Console.WriteLine("message\n" + incomingMessage+"\n");
              

                    if(incomingMessage == "OK")  //successful connection
                    {
                        button_connect.Enabled = false;
                        textBox_sweet.Enabled = true;
                        button_post.Enabled = true;
                        connected = true;
                        button_disconnect.Enabled = true;
                        button_feed.Enabled = true;
                        button_follow.Enabled = true;
                        textBox_username_follow.Enabled = true;
                        button_user_request.Enabled = true;
                        button_sweet_f.Enabled = true;
                        logs.AppendText("\nConnected to the server!\n");
                        
                    }
                    else
                    {
                        if(incomingMessage == "CLOSE_")  //when the server is disconnected
                        {
                            
                            if (!terminating)
                            {
                                logs.AppendText("Server disconnected!\n");
                                button_connect.Enabled = true;
                                button_disconnect.Enabled = false;
                                textBox_sweet.Enabled = false;
                                button_post.Enabled = false;
                                button_follow.Enabled = false;
                                textBox_username_follow.Enabled = false;
                                button_user_request.Enabled = false;
                                button_sweet_f.Enabled = false;
                                button_feed.Enabled = false;
                            }

                            clientSocket.Close();
                            connected = false;
                        }
                        if (incomingMessage.Length >= 5)
                        {
                            string type = incomingMessage.Substring(0, 5);
                            if (type == "ERROR")                                 //if there is an error message on the server side such as non-existent username
                            {
                                logs.AppendText("\n"+incomingMessage.Substring(5) + "\n");
                                string e1 = "ERRORThis username does not exist in database\n";
                                string e2 = "ERRORClient " + textBox_username.Text + " is already connected\n";
                                if(incomingMessage == e1 || incomingMessage == e2)
                                {
                                    if (!terminating)
                                    {
                                        
                                        button_connect.Enabled = true;
                                        button_disconnect.Enabled = false;
                                        textBox_sweet.Enabled = false;
                                        button_post.Enabled = false;
                                        button_follow.Enabled = false;
                                        button_feed.Enabled = false;
                                        textBox_username_follow.Enabled = false;
                                        button_user_request.Enabled = false;
                                        button_sweet_f.Enabled = false;
                                        terminating = true;
                                    }

                                    clientSocket.Close();
                                    connected = false;
                                }
                            }
                            else if (type == "lengt")     //size of the sweet feed is sent beforehand to set the buffer size
                            {
                                
                                string size_str = incomingMessage.Substring(6);
                                if(size_str == "0")
                                {
                                    logs.AppendText("\n"+incomingMessage.Substring(6) + "\n");
                                }
                                else {
                                    int size;
                                    if (Int32.TryParse(size_str, out size))
                                    {
                                        Byte[] buffer2 = new Byte[size+10];  //buffer size is set dynamically
                                        clientSocket.Receive(buffer2);
                                        string incomingMessage2 = Encoding.Default.GetString(buffer2);
                                        incomingMessage2 = incomingMessage2.Substring(0, incomingMessage2.IndexOf("\0"));
                                       
                                        //showing the sweets in a readable format

                                        logs.AppendText("\nSWEET FEED:\n\n");
                                        string[] sweets = incomingMessage2.Split('\n');
                                        int c = 0;
                                        foreach (var sweet in sweets)
                                        {
                                            string[] sweet_details = sweet.Split('\t');
                                            logs.AppendText("ID: " + sweet_details[1] + "\n");
                                            logs.AppendText("Username: " + sweet_details[0] + "\n");
                                            logs.AppendText("Date and Time: " + sweet_details[2] + "\n");
                                            logs.AppendText("Sweet: " + sweet_details[3] + "\n\n");
                                            c++;
                                        }
                                    }
                                }
                                
                            }
                            else if(type == "users")  //to show the list of users
                            {
                                string incomingMessage3 = incomingMessage.Substring(5);

                                //showing the usernames

                                logs.AppendText("\nUSERS:\n");
                                string[] users = incomingMessage3.Split('\n');
                                foreach (var user in users)
                                {
                                    logs.AppendText(user + "\n");
                                    
                                }
                            }
                            else if(type == "sweef")  //to show the list of sweets of followed users
                            {
                                string incomingMessage2 = incomingMessage.Substring(5);

                                logs.AppendText("\nSWEETS OF FOLLOWED USERS:\n\n");
                                string[] sweets = incomingMessage2.Split('\n');
                                int c = 0;
                                foreach (var sweet in sweets)
                                {
                                    if (sweet != "")
                                    {
                                        string[] sweet_details = sweet.Split('\t');
                                        logs.AppendText("ID: " + sweet_details[1] + "\n");
                                        logs.AppendText("Username: " + sweet_details[0] + "\n");
                                        logs.AppendText("Date and Time: " + sweet_details[2] + "\n");
                                        logs.AppendText("Sweet: " + sweet_details[3] + "\n\n");
                                        c++;
                                    }
                                }
                            }

                        }
                    }
                }
                catch(Exception e) //if there is an error during receiving message
                {
                    Console.WriteLine(e.StackTrace);

                    if (!terminating)
                    {
                        logs.AppendText("\nThe Server disconnected!\n");
                        button_connect.Enabled = true;
                        button_disconnect.Enabled = false;
                        textBox_sweet.Enabled = false;
                        button_post.Enabled = false;
                        button_follow.Enabled = false;
                        button_feed.Enabled = false;
                        textBox_username_follow.Enabled = false;
                        button_user_request.Enabled = false;
                        button_sweet_f.Enabled = false;
                        terminating = true;
                    }

                    clientSocket.Close();
                    connected = false;
                }
            }
        }   

        private void button_post_Click(object sender, EventArgs e)
        {
            string sweet = textBox_sweet.Text;
            string keyword = "gkegcs40818";     //agreed-upon keyword

            if (sweet != "" && sweet.Length <= 1012)  //sweet length limit
            {
                Byte[] buffer = Encoding.Default.GetBytes(keyword+sweet);
                try
                {
                    clientSocket.Send(buffer);
                    logs.AppendText("\nYou posted a new sweet: " + sweet + "\n");
                }
                catch
                {
                    logs.AppendText("\nCould not send the sweet!\n");
                }
                
            }
            else
            {
                logs.AppendText("\nThe sweet length must be in the range [1, 1012]!\n");
            }
        }

        private void button_feed_Click(object sender, EventArgs e)  
        {
            string keyword = "gkegcs40818";   //agreed-upon keyword
            Byte[] buffer = Encoding.Default.GetBytes(keyword);   //keyword is sent if the user clicks on sweet feed button
            try
            {
                clientSocket.Send(buffer);
                logs.AppendText("\nYou requested sweet feed!\n");
            }
            catch
            {
                logs.AppendText("\nCould not send the sweet feed request!\n");
            }                           
        }


        private void button_disconnect_Click(object sender, EventArgs e)
        {
            logs.AppendText("\nDisconnected from the server!\n");

            string message = "Disconnected" + textBox_username.Text;  //disconnected message is sent right before closing the socket to inform the server
            Byte[] buffer = Encoding.Default.GetBytes(message);
            clientSocket.Send(buffer);

            button_connect.Enabled = true;
            button_disconnect.Enabled = false;
            textBox_sweet.Enabled = false;
            button_post.Enabled = false;
            button_feed.Enabled = false;
            button_follow.Enabled = false;
            textBox_username_follow.Enabled = false;
            button_user_request.Enabled = false;
            button_sweet_f.Enabled = false;
            clientSocket.Close();
            connected = false;
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (connected) {
                string message = "Disconnected" + textBox_username.Text;
                Byte[] buffer = Encoding.Default.GetBytes(message);       //disconnected message is sent right before closing the socket to inform the server
                clientSocket.Send(buffer);
            }
            connected = false;
            terminating = true;
            if(clientSocket!=null)
            {
                clientSocket.Close();
            }
            Environment.Exit(0);
        }

        private void button_sweet_f_Click(object sender, EventArgs e)  //sweets of the followed users
        {
            string keyword = "sweef";   //agreed-upon keyword
            Byte[] buffer = Encoding.Default.GetBytes(keyword);   //keyword is sent if the user clicks on sweets of my followings button
            try
            {
                clientSocket.Send(buffer);
                logs.AppendText("\nYou requested sweets of your followings!\n");
            }
            catch
            {
                logs.AppendText("\nCould not send the sweet feed request!\n");
            }
        }

        private void button_user_request_Click(object sender, EventArgs e)
        {
            string keyword = "users";   //agreed-upon keyword
            Byte[] buffer = Encoding.Default.GetBytes(keyword);   //keyword is sent if the user clicks on show all users button
            try
            {
                clientSocket.Send(buffer);
                logs.AppendText("\nYou requested to see all the users!\n");
            }
            catch
            {
                logs.AppendText("\nCould not send the user request!\n");
            }
        }

        private void button_follow_Click(object sender, EventArgs e)
        {
            string username = textBox_username.Text;
            string usernameToFollow = textBox_username_follow.Text;
            string keyword = "follow";     //agreed-upon keyword

            Byte[] buffer = Encoding.Default.GetBytes(keyword + "-" + username + "-" + usernameToFollow);
            try
            {
                clientSocket.Send(buffer);
                logs.AppendText("\nYou requested to follow " + usernameToFollow + ".\n");
            }
            catch
            {
                logs.AppendText("\nCould not send the follow request!\n");
            }
        }
    }
}