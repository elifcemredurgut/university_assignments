﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.IO;

namespace ProjectStep1Server
{
    public partial class Form_server : Form
    {
        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        List<Socket> clientSockets = new List<Socket>(); //list that keeps client sockets
        List<string> userNames = new List<string>(); //list that keeps the list of usernames
        List<string> connectedUsers = new List<string>();//to keep track of connected users

        int counter = 0;
        //string userDb = "C:\\Users\\suuser\\Desktop\\user-db.txt";
        //string sweetsDb = "C:\\Users\\suuser\\Desktop\\sweetdatabase.txt";

        //string userDb = "C:\\Users\\HP\\Desktop\\projectStep1\\projectStep1\\user-db.txt";
        //string sweetsDb = "C:\\Users\\HP\\Desktop\\projectStep1\\projectStep1\\sweetdatabase.txt";

        string userDb = "C:\\Users\\elifc\\Downloads\\cs408\\projectStep1\\user-db.txt";
        string sweetsDb = "C:\\Users\\elifc\\Downloads\\cs408\\projectStep1\\sweetdatabase.txt";

        bool terminating = false;
        bool listening = false;
        

        public Form_server()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form_server_FormClosing);
            InitializeComponent();

            foreach (string line in File.ReadLines(@userDb))
            {
                userNames.Add(line);
                counter++;
            }
        }

        private void Form_server_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (connectedUsers.Count() > 0) {
                Byte[] reportBuffer = Encoding.Default.GetBytes("CLOSE_");
                foreach(Socket s in clientSockets) {
                    s.Send(reportBuffer);
                }
            }
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }
        private void Accept()
        {
            Console.WriteLine(listening);
            while (listening)
            {
                try
                {
                    Socket newClient = serverSocket.Accept(); //create a socket for new connection
                    Byte[] username_buffer = new Byte[1024];
                    newClient.Receive(username_buffer); //receive the username of the client

                    string receivedUserName = Encoding.Default.GetString(username_buffer);
                    receivedUserName = receivedUserName.Substring(0, receivedUserName.IndexOf("\0"));


                    if (userNames.Contains(receivedUserName)) // if the username exists in given user-database
                    {
                        if (connectedUsers.Contains(receivedUserName)) //if the username is alreadu connected
                        {
                            logs.AppendText(DateTime.Now + " Client " + receivedUserName + " is already connected\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + connectedUsers.Count + "\n");
                            //report to the client
                            Byte[] reportBuffer = Encoding.Default.GetBytes("ERROR" + "Client " + receivedUserName + " is already connected\n");
                            newClient.Send(reportBuffer);

                            newClient.Close();

                        }
                        else
                        {
                            clientSockets.Add(newClient);  // add the client to the client sockets
                            connectedUsers.Add(receivedUserName); //add the client to connected clients' list

                            logs.AppendText(DateTime.Now + " Client " + receivedUserName + " is connected\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + connectedUsers.Count + "\n");

                            Byte[] reportBuffer = Encoding.Default.GetBytes("OK");
                            newClient.Send(reportBuffer);

                            Thread receivedThread = new Thread(() => Receive(newClient, receivedUserName));
                            receivedThread.Start();
                        }
                    }
                    else
                    {
                        logs.AppendText(DateTime.Now + "Client " + receivedUserName + " is not registered!\n"); //if the username is not from the users-db
                        Byte[] reportBuffer = Encoding.Default.GetBytes("ERRORThis username does not exist in database\n");
                        newClient.Send(reportBuffer);

                        newClient.Close();
                    }
                }
                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText(DateTime.Now + " Socket stopped\n");
                        textBox_port.Enabled = true;
                        button_listen.Enabled = true;
                        listening = false;
                    }
                }
            }
        }
        private void Receive(Socket thisClient, string username)
        {
            bool connected = true;
            while (connected && !terminating)
            {
                try
                {
                    Byte[] sweet_buffer = new Byte[1024];
                    thisClient.Receive(sweet_buffer);

                    string request = Encoding.Default.GetString(sweet_buffer);
                    request = request.Substring(0, request.IndexOf("\0"));
                    string sweet;

                    if (request.Length > 11)
                    {
                        string keyword = request.Substring(0, 11);  //server and client agrees on a keyword
                        if (keyword == "gkegcs40818")
                        {
                            sweet = request.Substring(11, request.Length - 11);
                            PostSweet(thisClient, username, sweet);
                        }
                    }
                    else if (request.Length == 11 && request == "gkegcs40818")
                    {//get sweet feed
                        SendSweetFeed(thisClient, username);
                        logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count) + "\n");
                    }else if(request.Length >= 12 && request.Substring(0, 12) == "Disconnected")
                    {
                        Console.WriteLine("disconnect");
                        if (!terminating)
                        {
                            logs.AppendText(DateTime.Now + " Client " + username + " has disconnected.\n");
                            logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count - 1) + "\n");
                        }
                        thisClient.Close(); //close socket connection 
                        clientSockets.Remove(thisClient); //remove from the socket list
                        connectedUsers.Remove(username); //remove from the connected users' list
                        connected = false;
                    }
                }
                catch (Exception e)
                {
                    
                    Console.WriteLine(e);
                    if (!terminating)
                    {
                        logs.AppendText(DateTime.Now + " Client " + username + " has disconnected.\n");
                        logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count - 1) + "\n");
                    }
                    thisClient.Close(); //close socket connection 
                    clientSockets.Remove(thisClient); //remove from the socket list
                    connectedUsers.Remove(username); //remove from the connected users' list
                    connected = false;
                }

            }
        }
        private int getID()
        {
            string lastLine = "";
            int unique_id;
            var lst = File.ReadLines(@sweetsDb);
            foreach (var line in lst)
            {
                lastLine = line;
            }

            
            if (lastLine == "SWEET DATABASE" || (lastLine == "" && lst.Count() == 2))
            {
                return 0;
            }
            else
            {
                string substring_line = lastLine.Substring(lastLine.IndexOf(" ") + 1);
                unique_id = Int32.Parse(substring_line.Substring(0, substring_line.IndexOf(" ")));
            }
            return unique_id + 1;

        }
        private void PostSweet(Socket thisClient, string username, string sweet)
        {
            int unique_id = getID();
            string new_sweet = username + " " + unique_id + " " + DateTime.Now + "*" + sweet;

            // Creating a file
            string myfile = @sweetsDb;

            // Appending the given texts
            using (StreamWriter sw = File.AppendText(myfile))
            {
                sw.WriteLine(new_sweet);
            }

            logs.AppendText(DateTime.Now + " sweet by " + username + " was posted\n");
        }
        private void SendSweetFeed(Socket thisClient, string clientUsername)
        {
            if (!terminating)
            {
                try
                {
                    var lines = File.ReadLines(@sweetsDb);
                    int lineNum = 0;
                    string sweet_feed = "";
                    long size_Int = new System.IO.FileInfo(@sweetsDb).Length;
                    string size = "length" + size_Int.ToString();

                    Byte[] sizeBuffer = Encoding.Default.GetBytes(size);
                    try
                    {

                        thisClient.Send(sizeBuffer);
                    }
                    catch
                    {
                        Console.WriteLine("Problem sending the file size!");
                    }
                    foreach (var line in lines)
                    {
                        if (lineNum > 0)
                        {
                            
                            string username = line.Substring(0, line.IndexOf(" "));
                            string substring_line = line.Substring(line.IndexOf(" ") + 1);
                            string sweet_id = substring_line.Substring(0, substring_line.IndexOf(" "));

                            string substring_line2 = substring_line.Substring(substring_line.IndexOf(" ") + 1);
                            string time_ = substring_line2.Substring(0, substring_line2.IndexOf("*"));

                            string sweet_ = substring_line2.Substring(substring_line2.IndexOf("*") + 1);

                            if (username != clientUsername) //user's own sweets shouldnt be added to sweet feed
                            {
                                sweet_feed += username + "\t" + sweet_id + "\t" + time_ + '\t' + sweet_ + "\n";
                            }

                        }
                        lineNum++;
                    }
                    if (sweet_feed.Length == 0)
                    {
                        Console.WriteLine("no sweet");
                        sweet_feed = "ERRORNo sweets yet!";
                    }else
                    {
                        sweet_feed = sweet_feed.Substring(0, sweet_feed.Length - 1);
                    }

                    Byte[] retBuffer = Encoding.Default.GetBytes(sweet_feed);
                    try
                    {

                        thisClient.Send(retBuffer);
                        logs.AppendText(DateTime.Now + "here Number of connected clients: " + (connectedUsers.Count) + "\n");

                    }
                    catch (Exception e)
                    {
                        System.Console.WriteLine(e.StackTrace);
                        //logs.AppendText("catch");
                    }
                    
                    logs.AppendText(DateTime.Now + " All the sweets by other users have been sent to " + clientUsername + "\n");
                    logs.AppendText(DateTime.Now + " Number of connected clients: " + (connectedUsers.Count) + "\n");

                }
                catch (Exception e)
                {
                    Byte[] errBuffer = Encoding.Default.GetBytes("ERROR" + "Server couldn't send the list of sweets");
                    try
                    {

                        thisClient.Send(errBuffer);
                    }
                    catch (Exception ex)
                    {
                        System.Console.WriteLine(ex.StackTrace);
                    }
                    logs.AppendText(DateTime.Now + " Error while sending the list of sweets!\n");
                }
            }
        }


        private void button_listen_Click(object sender, System.EventArgs e)
        {
            int serverPort;


            if (Int32.TryParse(textBox_port.Text, out serverPort)) //if the portnumber is provided correctly
            {
                listening = true;

                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);

                serverSocket.Bind(endPoint);
                serverSocket.Listen(counter); //counter is maximum number of clients 

                button_listen.Enabled = false;
                textBox_port.Enabled = false;



                if (!File.Exists(@sweetsDb))
                {
                    File.WriteAllText(@sweetsDb, "SWEET DATABASE\n");
                }

                Thread acceptThread = new Thread(Accept);
                acceptThread.Start();


                logs.AppendText("Started listening\n");
            }
            else
            {
                logs.AppendText("Please, check the port number!\n");
            }
        }

        private void logs_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void textBox_port_TextChanged(object sender, System.EventArgs e)
        {

        }

    }
}