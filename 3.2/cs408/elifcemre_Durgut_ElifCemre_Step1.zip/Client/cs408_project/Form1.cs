﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace cs408_project  //client side
{
    public partial class Form1 : Form
    {

        bool terminating = false;
        bool connected = false;
        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            //TCP connection
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = textBox_ip.Text;

            int portNum;
            if (Int32.TryParse(textBox_port.Text, out portNum))
            {
                try
                {
                    //connect
                    clientSocket.Connect(IP, portNum);
                    connected = true;

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();
                    

                    //send username
                    string username = textBox_username.Text;
                    Byte[] buffer = Encoding.Default.GetBytes(username);
                    clientSocket.Send(buffer);

                }
                catch
                {
                    logs.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                logs.AppendText("Check the port number!\n");
            }
        }

        private void Receive()
        {
            while (connected)
            {
                try
                {
                    //receive incoming message
                    Byte[] buffer = new Byte[2048];  
                    clientSocket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));

                    if(incomingMessage == "OK")  //successful connection
                    {
                        button_connect.Enabled = false;
                        textBox_sweet.Enabled = true;
                        button_post.Enabled = true;
                        connected = true;
                        button_disconnect.Enabled = true;
                        button_feed.Enabled = true;
                        logs.AppendText("Connected to the server!\n");
                        
                    }
                    else
                    {
                        if(incomingMessage.Length == 6 && incomingMessage == "CLOSE_")  //when the server is disconnected
                        {
                            
                            if (!terminating)
                            {
                                logs.AppendText("Server disconnected!\n");
                                button_connect.Enabled = true;
                                button_disconnect.Enabled = false;
                                textBox_sweet.Enabled = false;
                                button_post.Enabled = false;
                            }

                            clientSocket.Close();
                            connected = false;
                        }
                        Console.WriteLine(incomingMessage);
                        if (incomingMessage.Length >= 5)
                        {
                            string type = incomingMessage.Substring(0, 5);
                            if (type == "ERROR")                                 //if there is an error message on the server side such as non-existent username
                            {
                                logs.AppendText(incomingMessage.Substring(5) + "\n");
                            }
                            else if (type == "lengt")     //size of the sweet feed is sent beforehand to set the buffer size
                            {
                                
                                string size_str = incomingMessage.Substring(6);
                                if(size_str == "15")
                                {
                                    //logs.AppendText(incomingMessage.Substring(6) + "\n");
                                }
                                else {
                                    int size;
                                    if (Int32.TryParse(size_str, out size))
                                    {
                                        Byte[] buffer2 = new Byte[size];  //buffer size is set dynamically
                                        clientSocket.Receive(buffer2);
                                        string incomingMessage2 = Encoding.Default.GetString(buffer2);
                                        incomingMessage2 = incomingMessage2.Substring(0, incomingMessage2.IndexOf("\0"));

                                        //showing the sweets in a readable format

                                        logs.AppendText("SWEET FEED:\n\n");
                                        string[] sweets = incomingMessage2.Split('\n');
                                        int c = 0;
                                        foreach (var sweet in sweets)
                                        {
                                            string[] sweet_details = sweet.Split('\t');
                                            logs.AppendText("ID: " + sweet_details[1] + "\n");
                                            logs.AppendText("Username: " + sweet_details[0] + "\n");
                                            logs.AppendText("Date and Time: " + sweet_details[2] + "\n");
                                            logs.AppendText("Sweet: " + sweet_details[3] + "\n\n");
                                            c++;
                                        }
                                    }
                                }
                                
                            }

                        }
                    }
                }
                catch(Exception e) //if there is an error during receiving message
                {
                    Console.WriteLine(e.StackTrace);

                    if (!terminating)
                    {
                        logs.AppendText("The Server disonnected!\n");
                        button_connect.Enabled = true;
                        button_disconnect.Enabled = false;
                        textBox_sweet.Enabled = false;
                        button_post.Enabled = false;
                        terminating = true;
                    }

                    clientSocket.Close();
                    connected = false;
                }
            }
        }   

        private void button_post_Click(object sender, EventArgs e)
        {
            string sweet = textBox_sweet.Text;
            string keyword = "gkegcs40818";     //agreed-upon keyword

            if (sweet != "" && sweet.Length <= 1012)  //sweet length limit
            {
                Byte[] buffer = Encoding.Default.GetBytes(keyword+sweet);
                try
                {
                    clientSocket.Send(buffer);
                    logs.AppendText("You posted a new sweet: " + sweet + "\n");
                }
                catch
                {
                    logs.AppendText("Could not send the sweet!\n");
                }
                
            }
            else
            {
                logs.AppendText("The sweet length must be in the range [1, 1012]!\n");
            }
        }

        private void button_feed_Click(object sender, EventArgs e)  
        {
            string keyword = "gkegcs40818";   //agreed-upon keyword
            Byte[] buffer = Encoding.Default.GetBytes(keyword);   //keyword is sent if the user clicks on sweet feed button
            try
            {
                clientSocket.Send(buffer);
                logs.AppendText("You requested sweet feed!\n");
            }
            catch
            {
                logs.AppendText("Could not send the sweet feed request!\n");
            }                           
        }


        private void button_disconnect_Click(object sender, EventArgs e)
        {
            logs.AppendText("Disconnected from the server!\n");

            string message = "Disconnected" + textBox_username.Text;  //disconnected message is sent right before closing the socket to inform the server
            Byte[] buffer = Encoding.Default.GetBytes(message);
            clientSocket.Send(buffer);

            button_connect.Enabled = true;
            button_disconnect.Enabled = false;
            textBox_sweet.Enabled = false;
            button_post.Enabled = false;
            button_feed.Enabled = false;
            clientSocket.Close();
            connected = false;
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (connected) {
                string message = "Disconnected" + textBox_username.Text;
                Byte[] buffer = Encoding.Default.GetBytes(message);       //disconnected message is sent right before closing the socket to inform the server
                clientSocket.Send(buffer);
            }
            connected = false;
            terminating = true;
            if(clientSocket!=null)
            {
                clientSocket.Close();
            }
            Environment.Exit(0);
        }
    }
}