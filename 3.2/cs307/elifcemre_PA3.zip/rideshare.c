#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>
#include <semaphore.h>

//Elif Cemre Durgut - 26493
//CS307 Programming Assignment 3
//15.03.2021

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
int a = 0, b = 0;  //number of waiting fans
sem_t sem_a, sem_b;
int isDriving = 0;  
int isCaptain = 0;  //if there is no captain, it is 0

pthread_barrier_t barrier, barrier2;

void* thread_funcA(void* arg)
{
    printf("Thread ID: %ld, Team: A, I am looking for a car\n", pthread_self());
    
    pthread_mutex_lock(&lock);
    a++;
    isCaptain = 0;
    isDriving = 0;
    pthread_mutex_unlock(&lock);
    
    
    pthread_mutex_lock(&lock);
    if(isDriving == 0 && (a == 4) || (b == 4) || (a >= 2 && b >= 2) ){
        isDriving = 1;
        if(a == 4){
            sem_post(&sem_a);
            sem_post(&sem_a);
            sem_post(&sem_a);
            sem_post(&sem_a);
            a -= 4;
        }
        else{
            sem_post(&sem_a);
            sem_post(&sem_a);
            sem_post(&sem_b);
            sem_post(&sem_b);
            a -= 2;
            b -= 2;
        }
        pthread_mutex_unlock(&lock);
    } else{
        pthread_mutex_unlock(&lock);
        sem_wait(&sem_a);
    }
    
    pthread_barrier_wait(&barrier);
    printf("Thread ID: %ld, Team: A, I have found a spot in a car\n", pthread_self());
    pthread_barrier_wait(&barrier2);
    pthread_mutex_lock(&lock);
    if(isCaptain == 0){
        isCaptain = 1;
        printf("Thread ID: %ld, Team: A, I am the captain and driving the car\n", pthread_self());
    }
    pthread_mutex_unlock(&lock);
    return NULL;
}

void* thread_funcB(void* arg)
{
    printf("Thread ID: %ld, Team: B, I am looking for a car\n", pthread_self());
    
    pthread_mutex_lock(&lock);
    b++;
    isCaptain = 0;
    isDriving = 0;
    pthread_mutex_unlock(&lock);
    
    
    pthread_mutex_lock(&lock);
    if(isDriving == 0 && (a == 4) || (b == 4) || (a >= 2 && b >= 2) ){
        isDriving = 1;
        if(b == 4){
            sem_post(&sem_b);
            sem_post(&sem_b);
            sem_post(&sem_b);
            sem_post(&sem_b);
            b -= 4;
        }
        else{
            sem_post(&sem_a);
            sem_post(&sem_a);
            sem_post(&sem_b);
            sem_post(&sem_b);
            a -= 2;
            b -= 2;
        }
        pthread_mutex_unlock(&lock);
    } else{
        pthread_mutex_unlock(&lock);
        sem_wait(&sem_b);
    }
    
    pthread_barrier_wait(&barrier);
    printf("Thread ID: %ld, Team: B, I have found a spot in a car\n", pthread_self());
    pthread_barrier_wait(&barrier2);
    pthread_mutex_lock(&lock);
    if(isCaptain == 0){
        isCaptain = 1;
        printf("Thread ID: %ld, Team: B, I am the captain and driving the car\n", pthread_self());
    }
    pthread_mutex_unlock(&lock);
    return NULL;
}


int main(int argc, char **argv)
{
    char *s1 = argv[1];
    int num_a = atoi(s1);

    char *s2 = argv[2];
    int num_b = atoi(s2);

    if(num_a % 2 == 0 && num_b % 2 == 0 && (num_a+num_b) % 4 == 0){

        pthread_t threads[num_a+num_b];

        sem_init(&sem_a, 0, 0);
        sem_init(&sem_b, 0, 0);
        pthread_barrier_init(&barrier, NULL, 4);
        pthread_barrier_init(&barrier2, NULL, 4);

        //create a+b many fan threads
        for(int i = 0; i < num_a+num_b; i++){
            if(i < num_a){
                pthread_create(&threads[i], NULL, thread_funcA, NULL);
            } else{
                pthread_create(&threads[i], NULL, thread_funcB, NULL);
            }
            
        }

        //join the threads
        for(int i = 0; i < num_a+num_b; i++){
            pthread_join(threads[i], NULL);
        }

        sem_destroy(&sem_a);
        sem_destroy(&sem_b);

        pthread_barrier_destroy(&barrier);
        pthread_barrier_destroy(&barrier2);
    }

    printf("The main terminates\n");
    
    return 0;
}