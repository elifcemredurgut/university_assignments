#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>

//Elif Cemre Durgut - 26493
//CS307 Programming Assignment 2
//15.11.2021

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

int **board;
int N;
int turn = 1; //initally 1 for X, then becomes 2 for Y

int isDiagonalCrossed(){
    int diagonalX = 1; //true
    int diagonalO = 1; //true
    for(int i = 0; i < N; i++){
        if(board[i][i] != 1){
            diagonalX = 0;
        }
        if(board[i][i] != 2){
            diagonalO = 0;
        }
    }
    if(diagonalX == 1){
        return 1;
    }
    else if(diagonalO == 1){
        return 2;
    }
}

int isInverseDiagonalCrossed(){
    int diagonalX = 1; //true
    int diagonalO = 1; //true
    for(int i = 0; i < N; i++){
        if(board[i][N-i-1] != 1){
            diagonalX = 0;
        }
        if(board[i][N-i-1] != 2){
            diagonalO = 0;
        }
    }
    if(diagonalX == 1){
        return 1;
    }
    else if(diagonalO == 1){
        return 2;
    }
}

int isHorizontalCrossed(){
    for(int i = 0; i < N; i++){
        int horizontalX = 1;
        int horizontalO = 1;
        for(int j = 0; j < N; j++){
            if (board[i][j] != 1){
                horizontalX = 0;
            }
            if (board[i][j] != 2){
                horizontalO = 0;
            }
        }
        if(horizontalX == 1){
            return 1;
        }
        else if(horizontalO == 1){
            return 2;
        }
    }
    return 0;
}

int isVerticalCrossed(){
    for(int i = 0; i < N; i++){
        int verticalX = 1;
        int verticalO = 1;
        for(int j = 0; j < N; j++){
            if (board[j][i] != 1){
                verticalX  = 0;
            }
            if (board[j][i] != 2){
                verticalO = 0;
            }
        }
        if(verticalX  == 1){
            return 1;
        }
        else if(verticalO == 1){
            return 2;
        }
    }
    return 0;
}

int isBoardFull(){
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            if(board[i][j] == 0){
                return 0; //not full
            }
        }
    }
    return 1; //full
}

int isGameOver(){
    int k = isDiagonalCrossed();
    int l = isHorizontalCrossed();
    int m = isVerticalCrossed();
    int n = isInverseDiagonalCrossed();
    int f = isBoardFull();
    
    if(k == 1 || l == 1 || m == 1 || n == 1){  // X wins
        return 1;
    }
    else if(k == 2 || l == 2 || m == 2 || n == 2){  // O wins
        return 2;  
    }
    else if(f == 1){  // tie, board is full
        return -1;
    }
    else{  // not over  
        return 0;
    }
}

void printBoard(){
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            if(board[i][j] == 1){
                printf("[X] ");
            } else if(board[i][j] == 2){
                printf("[O] ");
            } else{
                printf("[ ] ");
            }
        }
        printf("\n");
    }
}

void* thread_func(void* arg){
    srand(time(NULL));
    
    int mark;
    if((int) arg == 1){
        mark = 1;
    }else{
        mark = 2;
    }

    while(isGameOver() == 0){
        if(turn == mark){
            pthread_mutex_lock(&lock);
            int row = rand() % (N);
            int col = rand() % (N);

            while(board[row][col] != 0){
                row = rand() % (N);
                col = rand() % (N);
            }
            
            board[row][col] = mark;
            if(mark == 1){
                printf("Player X played on: (%d,%d)\n", row, col);
            } else{
                printf("Player O played on: (%d,%d)\n", row, col);
            }
            
            if(turn == 1){
                turn = 2;
            }else{
                turn = 1;
            }
            pthread_mutex_unlock(&lock);
        }
        
    }
    return NULL;
}

int main(int argc, char **argv)
{
    char *a = argv[1];
    N = atoi(a);

    //Allocation of memory
    board = malloc(N * sizeof(int *));
    for(int i = 0; i < N; i++){
        board[i] = malloc(N * sizeof(int));
    }
    
    //Initializing all the cells as 
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            board[i][j] = 0;
        }
    }
    
    printf("Board Size: %dx%d\n", N, N);

    
    pthread_t threadX, threadO;
    pthread_create(&threadX, NULL, thread_func, (void *)(int) 1);
    pthread_create(&threadO, NULL, thread_func, (void *)(int) 2);

    pthread_join(threadX, NULL);
    pthread_join(threadO, NULL);

    int result = isGameOver();
    printf("Game over.\n");
    if (result == 1){
        printf("Winner is X.\n");
    }
    else if(result == 2){
        printf("Winner is O.\n");
    }
    else{
        printf("It is a tie.\n");
    }

    printBoard();

    //Deallocation of memory
    for(int i = 0; i < N; i++){
        free(board[i]);
    }
    free(board);

    return 0;
}