/**
 * Elif Cemre Durgut - 26493 - CS307 PA5
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <dirent.h>
#include <limits.h>

#define MAX_LEN 256

//global int for the number of entries in database.txt
int n;


//recursive function to correct all the files in (sub)directories
void listFiles(char *basePath, char db[n*3][MAX_LEN])
{
    char path[1000];
    struct dirent *dp;
    DIR *dir = opendir(basePath);

    // Unable to open directory stream
    if (!dir)
        return;

    while ((dp = readdir(dir)) != NULL)
    {
        if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0)
        {
            char pathToBeOpened[1000];
            strcpy(pathToBeOpened, basePath);
            strcat(pathToBeOpened, "/");
            strcat(pathToBeOpened, dp->d_name);

            struct stat path_stat;
            stat(pathToBeOpened, &path_stat);

            //if it is a regular file
            if(S_ISREG(path_stat.st_mode)){  
                
                int len = strlen(dp->d_name);
                char cwd[PATH_MAX];
                getcwd(cwd, sizeof(cwd));

                //if it is a txt file but not the database.txt in root dir
                if(len > 4 && strcmp(dp->d_name+len-4, ".txt") == 0 && !(strcmp(dp->d_name, "database.txt") == 0 && strcmp(basePath, cwd) == 0)){
                    
                    //open the file
                    FILE *fp = fopen(pathToBeOpened, "r+");

                    if(fp == NULL){
                        printf("Error opening %s!\n", dp->d_name);
                    }else{

                        //get thw words one by one in txt file
                        char word[30];
                        while(fscanf(fp, "%s", word) == 1){
                            int k;

                            //compare the word and the names in database.txt
                            for(k = 1; k < n*3; k=k+3){
                                if(strcmp(db[k], word) == 0){  //if a match is founf

                                    //go backwards to correct Mr./Ms.
                                    fseek(fp, -1*(strlen(word)+4), SEEK_CUR);
                                    if(strcmp(db[k-1], "f")==0)
                                        fputs("Ms.", fp);
                                    else
                                        fputs("Mr.", fp);
                                    
                                    //go forward to correct the last name
                                    fseek(fp, strlen(word)+2, SEEK_CUR);
                                    fputs(db[k+1], fp);
                                    
                                }
                            }
                        }
                        fclose(fp);
                        printf("%s is corrected.\n", dp->d_name);
                    }
                    
                }else{
                    printf("%s is not a txt file, skipped.\n", dp->d_name);
                }
            }else{
                printf("%s is a directory, skipped.\n", dp->d_name);
            }

            // Update the bath
            strcpy(path, basePath);
            strcat(path, "/");
            strcat(path, dp->d_name);

            listFiles(path, db);
        }
    }
    closedir(dir);
}

int main()
{
    FILE *fp;
    char cwd[PATH_MAX];
    char path[PATH_MAX];

    //get the current working directory path
    if (getcwd(cwd, sizeof(cwd)) != NULL) {

        strcpy(path, cwd);
        strcat(path, "/database.txt");

        fp = fopen(path, "r");

        if(fp == NULL){
            printf("Error opening database.txt file!");
            return 1;
        }

        char buffer[MAX_LEN];

        int numOfLines = 0, i = 0;
        while(fgets(buffer, MAX_LEN, fp)){
            numOfLines++;
        }
        n = numOfLines;

        //go to the beginning of the file
        fseek(fp, 0, SEEK_SET);


        //store the database in an array
        char db[numOfLines*3][MAX_LEN];

        while(fgets(buffer, MAX_LEN, fp)){
            buffer[strcspn(buffer, "\n")] = 0;
            int len = ftell(fp);
            char* piece = strtok(buffer, " ");
            while(piece != NULL){
                strcpy(db[i++], piece);
                piece = strtok(NULL, " ");
            }
            
        }

        fclose(fp);
        listFiles(cwd, db);
    }
    else{
        perror("getcwd() error");
        return 1;
    }
    return 0;
}