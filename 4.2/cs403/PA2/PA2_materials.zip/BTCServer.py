import Pyro4
from MyBlockChain import MyBlockChain

BTC = MyBlockChain("BTC")