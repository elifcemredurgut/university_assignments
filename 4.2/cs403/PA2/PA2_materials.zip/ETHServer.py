import Pyro4
from MyBlockChain import MyBlockChain

ETH = MyBlockChain("ETH")