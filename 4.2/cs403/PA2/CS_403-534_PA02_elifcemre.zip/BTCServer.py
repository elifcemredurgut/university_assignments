import Pyro4
from MyBlockChain import MyBlockChain

BTC = MyBlockChain("BTC")

with Pyro4.Daemon() as daemon:
    BTC_uri = daemon.register(BTC)
    with Pyro4.locateNS() as ns:
        ns.register("BTC", BTC_uri)
    print("BTC is registered.")
    daemon.requestLoop()


