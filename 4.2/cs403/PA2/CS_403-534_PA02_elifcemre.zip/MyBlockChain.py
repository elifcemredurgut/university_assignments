import Pyro4
import threading

@Pyro4.expose
class MyBlock:
    def __init__(self, transaction, args, nextBlock):
        self._txType = transaction
        self._args = args
        self._next = nextBlock

    @property
    def txType(self):
        return self._txType

    @property
    def args(self):
        return self._args

    @property
    def next(self):
        return self._next

@Pyro4.expose
#@Pyro4.behavior(instance_mode="single")
class MyBlockChain:
    def __init__(self, chainName):
        self.head = None
        self.chainName = chainName
        self.lock = threading.Lock()

    """ it gives "can't set attribute 'head' error ://
    @property
    def head(self):
        return self._head

    @property
    def chainName(self):
        return self._chainName

    @property
    def lock(self):
        return self._lock
    """
    def createAccount(self, amount):
        self.lock.acquire()
        ptr = self.head
        max = 0
        while (ptr is not None):
            if ptr.args[0] > max:
                max = ptr.args[0]
            ptr = ptr.next
        new_block = MyBlock("CREATEACCOUNT", (max+1, amount), self.head)
        self.head = new_block
        self.lock.release()
        return max+1

    def accountExists(self, id):
        idExists = False
        self.lock.acquire()
        ptr = self.head
        while(ptr is not None):
            if(ptr.args[0] == id):
                self.lock.release()
                return True
            ptr = ptr.next
        self.lock.release()
        return False

    def transfer(self, f, t, a): #variables: from, to, amount
        if(self.accountExists(f) and self.accountExists(t)):
            #calculate the amount in from's account
            balanceOfFrom = self.calculateBalance(f)
            balanceOfTo = self.calculateBalance(t)

            #check if from has enough money
            if a >= 0: #there is a transfer from "from" to "to"
                if balanceOfFrom >= a:
                    self.lock.acquire()
                    new_block = MyBlock("TRANSFER", (f,t,a), self.head)
                    self.head = new_block
                    self.lock.release()
                    return 1
                else:
                    return -1
            else:
                if balanceOfTo >= -a:
                    self.lock.acquire()
                    new_block = MyBlock("TRANSFER", (f,t,a), self.head)
                    self.head = new_block
                    self.lock.release()
                    return 1
                else:
                    return -1
        else:
            return -1
        

    def exchange(self, f, t, c, a): #from, to, chain, amount
        if(self.accountExists(f) and c.accountExists(t)):
            balanceOfFrom = self.calculateBalance(f)
            balanceOfTo = c.calculateBalance(t)
            #check if from has enough money
            if a >= 0: #there is a transfer from "from" to "to"
                if balanceOfFrom >= a:
                    self.lock.acquire()
                    c.lock.acquire()
                    new_block = MyBlock("EXCHANGE", (f,t,c,a), self.head)
                    self.head = new_block
                    new_block2 = MyBlock("EXCHANGE", (t,f,self.chainName,-1*a), c.head)
                    c.head = new_block2
                    self.lock.release()
                    c.lock.release()
                    return 1
                else:
                    return -1
            else:
                if balanceOfTo >= -a:
                    self.lock.acquire()
                    c.lock.acquire()
                    new_block = MyBlock("TRANSFER", (f,t,c,a), self.head)
                    self.head = new_block
                    new_block2 = MyBlock("EXCHANGE", (t,f,self.chainName,-1*a), c.head)
                    c.head = new_block2
                    self.lock.release()
                    c.lock.release()
                    return 1
                else:
                    return -1
        else:
            return -1

    def calculateBalance(self, id):
        amount = 0
        self.lock.acquire()
        ptr = self.head
        while(ptr is not None):
            if(ptr.args[0] == id and ptr.txType == "CREATEACCOUNT"):
                amount += ptr.args[1]
            elif(ptr.args[0] == id and ptr.txType == "TRANSFER"):
                amount -= ptr.args[2]
            elif(ptr.args[1] == id and ptr.txType == "TRANSFER"):
                amount += ptr.args[2]
            elif(ptr.args[0] == id and ptr.txType == "EXCHANGE"):
                amount -= ptr.args[3]
            elif(ptr.args[1] == id and ptr.txType == "EXCHANGE"):
                amount += ptr.args[3]
            ptr = ptr.next
        self.lock.release()
        return amount

    def printChain(self):
        self.lock.acquire()
        ptr = self.head
        while(ptr is not None):
            print("----------------")
            print(self.chainName)
            print(ptr.txType)
            print(ptr.args)
            ptr = ptr.next
        print("----------------")
        self.lock.release()