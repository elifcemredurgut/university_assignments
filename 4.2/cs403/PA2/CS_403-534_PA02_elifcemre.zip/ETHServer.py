import Pyro4
from MyBlockChain import MyBlockChain

ETH = MyBlockChain("ETH")

with Pyro4.Daemon() as daemon:
    ETH_uri = daemon.register(ETH)
    with Pyro4.locateNS() as ns:
        ns.register("ETH", ETH_uri)
    print("ETH is registered.")
    daemon.requestLoop()