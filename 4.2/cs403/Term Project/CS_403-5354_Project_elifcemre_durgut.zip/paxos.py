import random
from multiprocessing import Process, Barrier
import sys, os, threading, time, zmq

# sends "CRASH proposer" message to the target with probability prob and 
# sends msg to the target with probability 1−prob
def sendFailure (msg, proposer, target, prob):
    if random.random() > prob:
        target.send_string(msg)
    else:
        target.send_string("CRASH "+str(proposer))
    
# calls sendFailure to broadcast the message
def broadcastFailure (msg, proposer, sockets, prob):
    for i in sockets:
        sendFailure(msg, proposer, i, prob)

# process function
def PaxosNode (ID, prob, N, val, numRounds, joinbarrier, votebarrier):
    context = zmq.Context()

    # 1 PULL socket
    node = context.socket(zmq.PULL)
    node.bind("tcp://127.0.0.1:"+str(5550+ID))

    # N PUSH sockets
    sockets = []
    for i in range(N):
        zmq_socket = context.socket(zmq.PUSH)
        zmq_socket.connect("tcp://127.0.0.1:"+str(5550+i))
        sockets.append(zmq_socket)

    maxVotedRound = -1
    maxVotedVal = None 

    for i in range(numRounds):
        # deciding on the node role for the current round        
        if i % N == ID: # if the node is leader

            proposeVal = None 
            decision = None
            leaderJoined = False
            leaderProposed = False

            #JOIN PHASE

            broadcastFailure("START", ID, sockets, prob)
            print("ROUND", i, "STARTED WITH INITIAL VALUE:", val)
            numJoinsAndStart = 0
            for j in range(N):
                string = node.recv_string()
                print("LEADER OF", i, "RECEIVED IN JOIN PHASE:", string)
                if string[0:4] == "JOIN":
                    numJoinsAndStart += 1
                    msg, votedRound, votedValue = string.split()
                    votedRound = int(votedRound) if votedRound is not None else None
                    if maxVotedRound is None or votedRound > maxVotedRound:
                        maxVotedRound = votedRound
                        maxVotedVal = int(votedValue)
                elif string == "START":
                    numJoinsAndStart += 1
                    leaderJoined = True

            if numJoinsAndStart > N/2:
                proposeVal = maxVotedVal
                if leaderJoined:
                    if maxVotedRound == -1:  #none of the nodes has voted before
                        proposeVal = val
                    broadcastFailure("PROPOSE "+str(proposeVal), i%N, sockets, prob)
                    leaderProposed = True
                joinbarrier.wait()
            elif numJoinsAndStart <= N/2 or leaderJoined == False:
                #send directly to other nodes
                for k in range(N):
                    if k == ID:
                        continue
                    sockets[k].send_string("ROUNDCHANGE")
                print("LEADER OF ROUND", i, "CHANGED ROUND")
                joinbarrier.wait()
                votebarrier.wait()
            

            #VOTE PHASE

            if leaderProposed:
                numVotesAndPropose = 0
                for m in range(N):
                    string = node.recv_string()
                    print("LEADER OF", i, "RECEIVED IN VOTE PHASE:", string)
                    
                    if string[0:4] == "VOTE":
                        numVotesAndPropose += 1
                    elif len(string) >= 7 and string == "PROPOSE":
                        numVotesAndPropose += 1
            	#decision
                if numVotesAndPropose > N/2:  
                    decision = proposeVal
                    print("LEADER OF", i, "DECIDED ON VALUE:", decision)

                votebarrier.wait()

        else: # if the node is acceptor

            #JOIN PHASE

            string = node.recv_string()
            print("ACCEPTOR", ID, "RECEIVED IN JOIN PHASE:", string)
            if string == "START":
                sendFailure("JOIN "+ str(maxVotedRound) + " " + str(maxVotedVal), i%N, sockets[i%N], prob)  # variablelear sıkıntı?
            elif string[0:5] == "CRASH":
                sockets[i % N].send_string("CRASH "+str(i % N))
            joinbarrier.wait()


            #VOTE PHASE

            string = node.recv_string()
            print("ACCEPTOR", ID, "RECEIVED IN VOTE PHASE:", string)
            if len(string) >= 7 and string[0:7] == "PROPOSE":
                msg, value = string.split()
                sendFailure("VOTE", i%N, sockets[i%N], prob)
                maxVotedRound = i
                maxVotedVal = value
                #move to the next round
            elif string == "ROUNDCHANGE":
                #move to the next round
                pass
            else: # CRASH message
                sockets[i % N].send_string("CRASH "+str(i%N))

            votebarrier.wait()

if __name__ == '__main__':
    numProc = int(sys.argv[1])    # total number of nodes/processes
    prob = float(sys.argv[2])     # probability of a node failure
    numRounds = int(sys.argv[3])  # number of rounds

    print("NUM NODES:", numProc, ", CRASH PROB:", prob, ", NUM ROUNDS:", numRounds)

    joinbarrier = Barrier(numProc)  #multiprocessing module to call at the end of join phase
    votebarrier = Barrier(numProc)  #multiprocessing module to call at the end of vote phase

    processes = []
    for nodeID in range(numProc):
        val = random.randint(0,1)
        nodeProcess = Process(target=PaxosNode, args=(nodeID, prob, numProc, val, numRounds, joinbarrier, votebarrier))
        processes.append(nodeProcess)

    for p in processes:
        p.start()

    for p in processes:
        p.join()