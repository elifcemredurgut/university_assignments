from random import sample
from multiprocessing import Process
import sys, os, threading, time, zmq

def leader(nodeID, isStarter, alive_nodes):
    LeaderMessage = threading.Event()           #signal to send leader message
    terminateMsg = threading.Event()            #signal to let process know that the leader has been set and it terminates
    cannotSendTerminateMsg = threading.Event()  #signal to let process know that there is a node with higher ID, so it cannot be a leader
    LeaderMsgSent = False

    print("PROCESS STARTS", os.getpid(), nodeID, isStarter)
    x = threading.Thread(target=responder, args=(nodeID, alive_nodes, LeaderMessage, terminateMsg, cannotSendTerminateMsg))
    x.start()

    context = zmq.Context()
    publisher = context.socket(zmq.PUB)
    publisher.bind("tcp://127.0.0.1:"+str(5555+nodeID))

    time.sleep(1) #wait for other processes/threads to bind/connect
    
    if isStarter:  #send LEADER if it is a starter node
        publisher.send_string("LEADER "+str(nodeID)) 
        print("PROCESS MULTICASTS LEADER MESSAGE:", nodeID)
        LeaderMsgSent = True
        time.sleep(10)

    while True:
        if isStarter and not terminateMsg.is_set() and not cannotSendTerminateMsg.is_set():
            publisher.send_string("TERMINATE "+str(nodeID))
            print("PROCESS BROADCASTS TERMINATE MSG:", nodeID)
            break  

        if LeaderMessage.is_set() and not LeaderMsgSent:   #
            publisher.send_string("LEADER "+str(nodeID))  
            print("PROCESS MULTICASTS LEADER MESSAGE:", nodeID)
            LeaderMsgSent = True
            time.sleep(10)

            if not terminateMsg.is_set() and not cannotSendTerminateMsg.is_set():
                publisher.send_string("TERMINATE "+str(nodeID))
                print("PROCESS BROADCASTS TERMINATE MSG:", nodeID)
                break  

        if terminateMsg.is_set():  #if the leader has been set
            break
    x.join()


def responder(nodeID, alive_nodes, LeaderMsg, terminateMsg, cannotSendTerminateMsg):  
    print("RESPONDER STARTS", nodeID)

    context = zmq.Context()
    listener = context.socket(zmq.SUB)

    for i in alive_nodes:
        listener.connect("tcp://127.0.0.1:"+str(5555+i))
    listener.subscribe(b'LEADER')  
    listener.subscribe(b'TERMINATE')

    while True:
        event = listener.poll(timeout=3000)  # wait 3 seconds
        if event == 0:
            # timeout reached before any events were queued
            pass
        else:
            # events queued within our time limit
            string = listener.recv_string()
            topic, msg = string.split()
            if topic == "LEADER":
                senderID = int(msg)
                if senderID < nodeID:
                    print("RESPONDER RESPONDS", nodeID, senderID)
                    LeaderMsg.set()
                elif senderID > nodeID:
                    cannotSendTerminateMsg.set()
            elif topic == "TERMINATE":
                terminateMsg.set()
                break
        
if __name__ == '__main__':
    numProc = int(sys.argv[1])  #total number of nodes
    numAlive = int(sys.argv[2])  #number of nodes that are alive
    numStarters = int(sys.argv[3])  #number of nodes that will initiate the protocol

    alive_nodes = sample(range(numProc), numAlive)
    print("Alives:")
    print(alive_nodes)

    starters = sample(alive_nodes, numStarters)
    print("Starters:")
    print(starters)

    processes = []
    for nodeID in alive_nodes:
        isStarter = True if nodeID in starters else False
        leader_process = Process(target=leader, args=(nodeID, isStarter, alive_nodes,))
        processes.append(leader_process)

    for p in processes:
        p.start()

    for p in processes:
        p.join()