from MapReduce import MapReduce


class FindCyclicReferences(MapReduce):
    def Map():
        pass
    def Reduce():
    	pass
