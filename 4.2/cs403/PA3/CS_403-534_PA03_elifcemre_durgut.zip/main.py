import sys
from FindCitations import FindCitations
import FindCyclicReferences

typ = sys.argv[1]
num = int(sys.argv[2])
file_name = sys.argv[3]

if typ == "COUNT":
    instance = FindCitations(num)
    print("instance created- main.py")
    instance.start(file_name)
elif typ == "CYCLE":
    print("I could not find time to implement this :(")
    #instance = FindCyclicReferences(num)
    #instance.start(file_name)
else:
    print("You have antered an invalid operation type!")


