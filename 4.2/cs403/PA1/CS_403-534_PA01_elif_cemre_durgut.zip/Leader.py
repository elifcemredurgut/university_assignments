import threading
import ConSet
import random
import time

n = 3
round = 1

#Global list that stores mailboxes
l = []
for i in range(n):
    mailbox = ConSet.MultiSet()
    l.append(mailbox)

def nodeWork(id, n, round):
    while True:
        randInt = random.randint(0, n**2)
        print("Node "+str(id)+" proposes value "+str(randInt)+" for round "+str(round)+".\n", end="")

        #send your integer to other nodes
        for i in range(n):
            if id == i:
                continue
            else:
                l[i].add([randInt, id, round])

        #take the messages from its mailbox
        numbersByNodes = [0] * n
        numbersByNodes[id] = randInt

        counter = 0
        while counter < n-1:
            removedElement = l[id].remove()
            if removedElement is not None:
                counter += 1
                
                if removedElement[2] == round:
                    numbersByNodes[removedElement[1]] = removedElement[0]
            #time.sleep(0.5)

        maxInt = max(numbersByNodes)
        if numbersByNodes.count(maxInt) == 1:  #if the maxInt is unique
            print("Node "+str(id)+" decided "+str(numbersByNodes.index(maxInt))+" as the leader.\n", end="")
            break
        else:
            print("Node "+str(id)+" could not decide on the leader and moves to the round "+str(round+1)+".\n",end="")
            round += 1
        

#Create threads
threads = []
for i in range(n):
    t = threading.Thread(target=nodeWork, args=(i,n,round,))
    t.start()
    threads.append(t)

# Wait all threads to finish
for t in threads:
    t.join()


