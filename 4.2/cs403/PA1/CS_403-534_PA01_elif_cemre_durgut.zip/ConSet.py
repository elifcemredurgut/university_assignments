from threading import Lock

class Node:
    def __init__(self, item=None):
        self.item = item  #number, id, round
        self.next = None

class MultiSet:

    def __init__(self):
        self.head = Node([-1,0,0])
        self.lock = Lock()

    def add(self, element):  # element = [number, id, round]
        new_node = Node(element)
        self.lock.acquire()
        current = self.head
        while(current.next is not None and current.next.item[0] < new_node.item[0]):
            current = current.next
            
        new_node.next = current.next
        current.next = new_node
        self.lock.release()

    def remove(self):  #removes the last element and returns it
        self.lock.acquire()
        pred = self.head
        curr = pred.next

        if(curr == None):
            self.lock.release()
            return None
        else:
            while(curr.next is not None):
                pred = curr
                curr = curr.next
            pred.next = None
            self.lock.release()
            return curr.item


